<?php
/**
 * Plugin Name: Yoshilover 063 Frontend (topic hub / SNS reactions / Phase 1 noindex)
 * Description: 062 contract §2 §3 §5 の front impl。topic hub / SNS block / noindex を基盤に、トップ速報帯・記事下回遊束・右カラム rail・上部密集ナビ・人気記事導線まで含めて SWELL front を高密度化する。既存 SWELL コメント欄は触らない。
 * Version: 0.16.1
 * Author: yoshilover
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'rest_api_init', 'yoshilover_063_register_admin_routes' );

/* ------------------------------------------------------------
 * 1) トップ中央 topic hub (062 §2 / 063 §1)
 *
 *    手動表示前提。固定ページ / トップページに
 *    [yoshilover_topic_hub] shortcode を貼るか、
 *    `.yoshi-topic-hub` ネームスペースの HTML を直接書く。
 *
 *    shortcode で出す場合、hub item は下記のいずれかで渡す:
 *      (a) WP option `yoshilover_topic_hub_items` (array)
 *      (b) filter `yoshilover_topic_hub_items`
 *
 *    item の shape:
 *      array(
 *        'title' => string (必須),
 *        'url'   => string (必須、canonical URL),
 *        'lead'  => string (任意、1 行リード),
 *        'badge' => string (任意、短いタグ文字),
 *      )
 *
 *    最大 5 件まで。空なら shortcode は空文字を返す。
 * ---------------------------------------------------------- */

add_shortcode( 'yoshilover_topic_hub', 'yoshilover_063_render_topic_hub' );
add_shortcode( 'yoshilover_dense_nav', 'yoshilover_063_render_dense_nav' );
add_shortcode( 'yoshilover_breaking_strip', 'yoshilover_063_render_breaking_strip' );
add_shortcode( 'yoshilover_today_giants_box', 'yoshilover_063_render_today_giants_box' );
add_shortcode( 'yoshilover_063_today_giants_fan_guide', 'yoshilover_063_render_today_giants_fan_guide' );
add_shortcode( 'yoshilover_sidebar_rail', 'yoshilover_063_render_sidebar_rail' );
add_action( 'dynamic_sidebar_before', 'yoshilover_063_auto_inject_sidebar_top_ad_slot', 4, 2 );
add_action( 'dynamic_sidebar_before', 'yoshilover_063_auto_inject_sidebar_rail', 5, 2 );

function yoshilover_063_get_topic_hub_items() {
    $items = get_option( 'yoshilover_topic_hub_items', array() );
    if ( ! is_array( $items ) ) {
        $items = array();
    }
    $items = apply_filters( 'yoshilover_topic_hub_items', $items );
    if ( ! is_array( $items ) ) {
        return array();
    }
    return array_slice( $items, 0, 5 );
}

function yoshilover_063_sanitize_topic_hub_items( $items ) {
    if ( ! is_array( $items ) ) {
        return array();
    }

    $sanitized = array();
    foreach ( $items as $item ) {
        if ( ! is_array( $item ) ) {
            continue;
        }
        $title = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
        $url   = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
        $lead  = isset( $item['lead'] ) ? trim( (string) $item['lead'] ) : '';
        $badge = isset( $item['badge'] ) ? trim( (string) $item['badge'] ) : '';

        if ( $title === '' || $url === '' ) {
            continue;
        }

        $sanitized[] = array(
            'title' => $title,
            'url'   => esc_url_raw( $url ),
            'lead'  => $lead,
            'badge' => $badge,
        );
    }

    return array_slice( $sanitized, 0, 5 );
}

function yoshilover_063_render_topic_hub( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'heading' => '今週の話題',
        ),
        $atts,
        'yoshilover_topic_hub'
    );

    $items = yoshilover_063_get_topic_hub_items();
    if ( empty( $items ) ) {
        return '';
    }

    $html  = '<aside class="yoshi-topic-hub" aria-label="topic hub" data-yoshi-phase="1">';
    $html .= '<h2 class="yoshi-topic-hub__heading">' . esc_html( $atts['heading'] ) . '</h2>';
    $html .= '<ul class="yoshi-topic-hub__items">';

    foreach ( $items as $item ) {
        if ( ! is_array( $item ) ) {
            continue;
        }
        $title = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
        $url   = isset( $item['url'] )   ? trim( (string) $item['url'] )   : '';
        $lead  = isset( $item['lead'] )  ? trim( (string) $item['lead'] )  : '';
        $badge = isset( $item['badge'] ) ? trim( (string) $item['badge'] ) : '';

        if ( $title === '' || $url === '' ) {
            continue;
        }

        $html .= '<li class="yoshi-topic-hub__item">';
        $html .= '<a class="yoshi-topic-hub__link" href="' . esc_url( $url ) . '" rel="nofollow">';
        if ( $badge !== '' ) {
            $html .= '<span class="yoshi-topic-hub__badge">' . esc_html( $badge ) . '</span>';
        }
        $html .= '<span class="yoshi-topic-hub__title">' . esc_html( $title ) . '</span>';
        if ( $lead !== '' ) {
            $html .= '<span class="yoshi-topic-hub__lead">' . esc_html( $lead ) . '</span>';
        }
        $html .= '</a>';
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</aside>';

    return $html;
}

function yoshilover_063_get_term_link_candidates( $taxonomy, $candidate_keys ) {
    $items = array();

    foreach ( (array) $candidate_keys as $candidate_key ) {
        $candidate_key = trim( (string) $candidate_key );
        if ( $candidate_key === '' ) {
            continue;
        }

        $term = get_term_by( 'slug', sanitize_title( $candidate_key ), $taxonomy );
        if ( ! $term instanceof WP_Term ) {
            $term = get_term_by( 'name', $candidate_key, $taxonomy );
        }
        if ( ! $term instanceof WP_Term ) {
            continue;
        }

        $url = get_term_link( $term );
        if ( is_wp_error( $url ) || ! is_string( $url ) || $url === '' ) {
            continue;
        }

        $items[] = array(
            'label' => $term->name,
            'url'   => $url,
        );
        break;
    }

    return $items;
}

/**
 * 388: post count 上位の player タグを dense nav に展開する。
 *
 * 既知の概念タグ (一軍 / 二軍 / 三軍 / 育成 / 速報 / 監督コメント /
 * OB解説 / 雑誌報道) と admin タグ (keep) は除外し、残った post_tag を
 * count 降順で並べる。 残った 上位 N 件は事実上ほぼ player 名タグになる
 * (387 で生成側が選手検出した name タグだけ付与する設計)。 cap=$limit。
 */
function yoshilover_063_get_top_player_tags( $limit = 30 ) {
    $exclude_names = array(
        'keep', '一軍', '二軍', '三軍', '育成', '速報',
        '監督コメント', 'OB解説', '雑誌報道',
    );

    $terms = get_terms( array(
        'taxonomy'   => 'post_tag',
        'orderby'    => 'count',
        'order'      => 'DESC',
        'number'     => max( 1, (int) $limit ) + count( $exclude_names ),
        'hide_empty' => true,
    ) );

    if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
        return array();
    }

    $items = array();
    foreach ( $terms as $term ) {
        if ( ! $term instanceof WP_Term ) {
            continue;
        }
        if ( in_array( $term->name, $exclude_names, true ) ) {
            continue;
        }
        $url = get_term_link( $term );
        if ( is_wp_error( $url ) || ! is_string( $url ) || $url === '' ) {
            continue;
        }
        $items[] = array(
            'label' => $term->name,
            'url'   => $url,
            'tone'  => 'player',
        );
        if ( count( $items ) >= $limit ) {
            break;
        }
    }

    return $items;
}

function yoshilover_063_get_dense_nav_items() {
    $items = array(
        array(
            'label' => 'HOME',
            'url'   => home_url( '/' ),
            'tone'  => 'home',
        ),
        array(
            'label' => '全記事',
            'url'   => home_url( '/' ),
            'tone'  => 'all',
        ),
    );

    $maps = array(
        array(
            'label'      => '選手',
            'taxonomy'   => 'post_tag',
            'candidates' => array( '選手', 'player', 'players', '読売ジャイアンツ', '巨人' ),
            'tone'       => 'players',
        ),
        array(
            'label'      => '監督',
            'taxonomy'   => 'post_tag',
            'candidates' => array( '監督', '阿部慎之助', '阿部監督', 'manager' ),
            'tone'       => 'manager',
        ),
        array(
            'label'      => '公示',
            'taxonomy'   => 'category',
            'candidates' => array( '公示', 'notice', '支配下登録', '昇格', '抹消' ),
            'tone'       => 'notice',
        ),
        array(
            'label'      => '試合結果',
            'taxonomy'   => 'category',
            'candidates' => array( '試合結果', '試合後', 'postgame', '試合' ),
            'tone'       => 'postgame',
        ),
        array(
            'label'      => 'ドラフト',
            'taxonomy'   => 'category',
            'candidates' => array( 'ドラフト', 'draft' ),
            'tone'       => 'draft',
        ),
        array(
            'label'      => '球団情報',
            'taxonomy'   => 'category',
            'candidates' => array( '球団情報', '巨人', 'ジャイアンツ', 'team', '球団' ),
            'tone'       => 'team',
        ),
    );

    foreach ( $maps as $map ) {
        $matched = yoshilover_063_get_term_link_candidates( $map['taxonomy'], $map['candidates'] );
        if ( empty( $matched ) ) {
            continue;
        }

        $items[] = array(
            'label' => $map['label'],
            'url'   => $matched[0]['url'],
            'tone'  => $map['tone'],
        );
    }

    // 388: 概念タグ (監督/公示/試合結果/球団情報) の後ろに player 名タグ
    // top 100 を付け足す (dnomotoke PC ヘッダー 133 player に追随)。
    // 既存タグと重複したら sanitize 段で seen dedupe。
    foreach ( yoshilover_063_get_top_player_tags( 100 ) as $player_item ) {
        $items[] = $player_item;
    }

    $items = apply_filters( 'yoshilover_063_dense_nav_items', $items );
    if ( ! is_array( $items ) ) {
        return array();
    }

    $seen = array();
    $sanitized = array();
    foreach ( $items as $item ) {
        if ( ! is_array( $item ) ) {
            continue;
        }

        $label = isset( $item['label'] ) ? trim( (string) $item['label'] ) : '';
        $url   = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
        $tone  = isset( $item['tone'] ) ? sanitize_key( (string) $item['tone'] ) : 'default';
        if ( $label === '' || $url === '' ) {
            continue;
        }
        $key = $label . '|' . $url;
        if ( isset( $seen[ $key ] ) ) {
            continue;
        }
        $seen[ $key ] = true;
        $sanitized[]  = array(
            'label' => $label,
            'url'   => esc_url_raw( $url ),
            'tone'  => $tone !== '' ? $tone : 'default',
        );
    }

    // 388: HOME / 全記事 / 概念 6 + player 100 = 約 108 件まで許容
    // (dnomotoke PC ヘッダー 136 link に追随)。
    return array_slice( $sanitized, 0, 150 );
}

function yoshilover_063_render_dense_nav( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'heading' => '回遊ナビ',
        ),
        $atts,
        'yoshilover_dense_nav'
    );

    $items = yoshilover_063_get_dense_nav_items();
    if ( empty( $items ) ) {
        return '';
    }

    $html  = '<nav class="yoshi-dense-nav" aria-label="' . esc_attr( $atts['heading'] ) . '" data-yoshi-phase="5">';
    // 388: dnomotoke PC ヘッダー風に nav 内に検索 form を埋め込む。
    // タイトル検索 (WP 標準 search)、 sidebar widget (390) と独立に動作。
    $html .= '<form role="search" method="get" class="yoshi-dense-nav__search" action="' . esc_url( home_url( '/' ) ) . '">';
    $html .= '<input type="search" name="s" class="yoshi-dense-nav__search-input" placeholder="記事タイトルで検索" aria-label="検索" />';
    $html .= '<button type="submit" class="yoshi-dense-nav__search-submit" aria-label="検索を実行">🔍</button>';
    $html .= '</form>';
    $html .= '<div class="yoshi-dense-nav__scroll">';
    $html .= '<ul class="yoshi-dense-nav__list">';

    foreach ( $items as $item ) {
        $html .= '<li class="yoshi-dense-nav__item">';
        $html .= '<a class="yoshi-dense-nav__link yoshi-dense-nav__link--' . esc_attr( $item['tone'] ) . '" href="' . esc_url( $item['url'] ) . '">';
        $html .= '<span class="yoshi-dense-nav__label">' . esc_html( $item['label'] ) . '</span>';
        $html .= '</a>';
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</div>';
    $html .= '</nav>';

    return $html;
}

function yoshilover_063_breaking_strip_target_subtypes() {
    return array(
        'live_update',
        'lineup',
        'notice',
        'probable_starter',
        'postgame',
    );
}

function yoshilover_063_get_breaking_strip_items( $limit = 5 ) {
    $limit = max( 1, min( 5, (int) $limit ) );
    $query = new WP_Query(
        array(
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'posts_per_page'         => 24,
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => false,
        )
    );

    $items   = array();
    $targets = yoshilover_063_breaking_strip_target_subtypes();

    foreach ( $query->posts as $post ) {
        if ( ! ( $post instanceof WP_Post ) ) {
            continue;
        }

        $text    = yoshilover_063_front_density_text( $post );
        $blob    = yoshilover_063_normalize_front_density_text( $post->post_title . ' ' . $text );
        $subtype = yoshilover_063_resolve_front_density_subtype( $post, $text );

        if ( ! in_array( $subtype, $targets, true ) ) {
            continue;
        }

        $items[] = array(
            'subtype' => $subtype,
            'label'   => yoshilover_063_front_density_subtype_label( $subtype ),
            'title'   => trim( (string) $post->post_title ),
            'url'     => get_permalink( $post ),
            'phase'   => yoshilover_063_extract_front_density_phase( $blob ),
            'score'   => yoshilover_063_extract_front_density_score( $blob ),
            'time'    => yoshilover_063_format_compact_post_time( $post ),
        );

        if ( count( $items ) >= $limit ) {
            break;
        }
    }

    wp_reset_postdata();

    return $items;
}

function yoshilover_063_render_breaking_strip( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'heading' => '速報帯',
            'limit'   => 5,
        ),
        $atts,
        'yoshilover_breaking_strip'
    );

    $items = yoshilover_063_get_breaking_strip_items( (int) $atts['limit'] );
    if ( empty( $items ) ) {
        return '';
    }

    $html  = '<aside class="yoshi-breaking-strip" aria-label="速報帯" data-yoshi-phase="3">';
    $html .= '<div class="yoshi-breaking-strip__head">';
    $html .= '<h2 class="yoshi-breaking-strip__heading">' . esc_html( $atts['heading'] ) . '</h2>';
    $html .= '<span class="yoshi-breaking-strip__note">試合中 / スタメン / 公示 / 予告先発 / 試合後</span>';
    $html .= '</div>';
    $html .= '<ul class="yoshi-breaking-strip__list">';

    foreach ( $items as $item ) {
        $html .= '<li class="yoshi-breaking-strip__item yoshi-breaking-strip__item--' . esc_attr( $item['subtype'] ) . '">';
        $html .= '<a class="yoshi-breaking-strip__link" href="' . esc_url( $item['url'] ) . '">';
        $html .= '<span class="yoshi-breaking-strip__eyebrow">';
        $html .= '<span class="yoshi-breaking-strip__badge">' . esc_html( $item['label'] ) . '</span>';
        if ( $item['phase'] !== '' ) {
            $html .= '<span class="yoshi-breaking-strip__chip yoshi-breaking-strip__chip--phase">' . esc_html( $item['phase'] ) . '</span>';
        }
        if ( $item['score'] !== '' ) {
            $html .= '<span class="yoshi-breaking-strip__chip yoshi-breaking-strip__chip--score">' . esc_html( $item['score'] ) . '</span>';
        }
        if ( $item['time'] !== '' ) {
            $html .= '<time class="yoshi-breaking-strip__time">' . esc_html( $item['time'] ) . '</time>';
        }
        $html .= '</span>';
        $html .= '<span class="yoshi-breaking-strip__title">' . esc_html( $item['title'] ) . '</span>';
        $html .= '</a>';
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</aside>';

    return $html;
}

function yoshilover_063_sidebar_primary_indexes() {
    return array(
        'sidebar-1',
        'sidebar',
        'swell_sidebar',
        'widget-area',
    );
}

function yoshilover_063_should_render_sidebar_rail() {
    if ( is_admin() || is_feed() || is_search() || is_404() ) {
        return false;
    }

    return is_front_page() || is_home() || is_singular( 'post' );
}

function yoshilover_063_is_primary_sidebar_index( $index ) {
    $index = strtolower( trim( (string) $index ) );
    if ( $index === '' ) {
        return false;
    }

    if ( in_array( $index, yoshilover_063_sidebar_primary_indexes(), true ) ) {
        return true;
    }

    return false !== strpos( $index, 'sidebar' ) && false === strpos( $index, 'footer' ) && false === strpos( $index, 'front_' );
}

function yoshilover_063_get_today_giants_box_items( $limit = 5 ) {
    $limit = max( 1, min( 5, (int) $limit ) );
    $items = array();
    $seen  = array();

    foreach ( yoshilover_063_get_breaking_strip_items( $limit ) as $item ) {
        $url = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
        if ( $url === '' || isset( $seen[ $url ] ) ) {
            continue;
        }

        $items[]      = array(
            'type'    => 'news',
            'subtype' => isset( $item['subtype'] ) ? $item['subtype'] : 'article',
            'label'   => isset( $item['label'] ) ? $item['label'] : '話題',
            'title'   => isset( $item['title'] ) ? $item['title'] : '',
            'url'     => $url,
            'phase'   => isset( $item['phase'] ) ? $item['phase'] : '',
            'score'   => isset( $item['score'] ) ? $item['score'] : '',
            'time'    => isset( $item['time'] ) ? $item['time'] : '',
        );
        $seen[ $url ] = true;

        if ( count( $items ) >= $limit ) {
            return $items;
        }
    }

    foreach ( yoshilover_063_get_topic_hub_items() as $item ) {
        $url = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
        if ( $url === '' || isset( $seen[ $url ] ) ) {
            continue;
        }

        $badge = isset( $item['badge'] ) ? trim( (string) $item['badge'] ) : '';
        $items[] = array(
            'type'    => 'topic',
            'subtype' => 'topic',
            'label'   => $badge !== '' ? $badge : '注目',
            'title'   => isset( $item['title'] ) ? trim( (string) $item['title'] ) : '',
            'url'     => $url,
            'phase'   => '',
            'score'   => '',
            'time'    => '',
        );
        $seen[ $url ] = true;

        if ( count( $items ) >= $limit ) {
            break;
        }
    }

    return $items;
}

function yoshilover_063_subtype_reader_label( $subtype ) {
    $map = array(
        'lineup'                 => 'スタメン確認',
        'pregame'                => '試合前の見どころ',
        'probable_starter'       => '予告先発',
        'postgame'               => '試合後の整理',
        'game_result'            => '試合結果',
        'coach_comment'          => 'ベンチの見方',
        'player_comment'         => '選手コメント',
        'farm_result'            => '二軍結果',
        'farm_lineup'            => '二軍スタメン',
        'farm_player_result'     => '若手・二軍メモ',
        'farm'                   => '二軍・若手',
        'roster_notice'          => '登録・抹消',
        'injury_recovery_notice' => '復帰・コンディション',
        'program_notice'         => '番組・配信',
    );

    $key = (string) $subtype;
    return isset( $map[ $key ] ) ? $map[ $key ] : '';
}

function yoshilover_063_is_weak_title( $title ) {
    $title  = yoshilover_063_normalize_front_density_text( (string) $title );
    $length = function_exists( 'mb_strlen' ) ? mb_strlen( $title, 'UTF-8' ) : strlen( $title );

    if ( $length < 12 ) {
        return true;
    }

    $weak_phrases = array(
        '実戦で何を見せるか',
        '何を見せるか',
        '注目ポイント',
        '今後に注目',
        '詳しくはこちら',
        '試合の詳細はこちら',
        '結果のポイント',
        '選手の適時打',
        '先発の 投手',
        '先発の投手',
    );

    foreach ( $weak_phrases as $phrase ) {
        if ( false !== strpos( $title, $phrase ) ) {
            return true;
        }
    }

    if ( in_array( $title, array( '【】', '速報', 'まとめ' ), true ) ) {
        return true;
    }

    $team_pattern    = implode(
        '|',
        array_map(
            'preg_quote',
            yoshilover_063_opponent_team_names()
        )
    );
    $strong_markers  = '/(巨人|ジャイアンツ|選手|監督|コーチ|スタメン|先発|試合|登録|抹消|復帰|公示|番組|配信|二軍|ファーム|若手|育成|' . $team_pattern . ')/u';
    $player_markers  = "/((?:[一-龠々]{2,4}|[ァ-ヴー]{2,12}|[A-Za-z][A-Za-z'\\- ]{1,20}))(?:投手|選手|監督|コーチ|捕手|内野手|外野手|が|は|の|、)/u";

    if ( ! preg_match( $strong_markers, $title ) && ! preg_match( $player_markers, $title ) ) {
        return true;
    }

    return false;
}

function yoshilover_063_today_giants_guide_raw_subtype( $post_id ) {
    $value = yoshilover_063_first_non_empty_meta(
        (int) $post_id,
        array(
            'article_subtype',
            '_article_subtype',
            'subtype',
            'article_type',
            '_article_type',
        )
    );

    if ( $value === '' ) {
        return '';
    }

    $value = strtolower( trim( (string) $value ) );
    return str_replace( array( '-', ' ' ), '_', $value );
}

function yoshilover_063_resolve_today_giants_guide_subtype( $post, $text = '' ) {
    $text     = $text !== '' ? $text : yoshilover_063_front_density_text( $post );
    $resolved = yoshilover_063_resolve_front_density_subtype( $post, $text );
    $raw      = yoshilover_063_today_giants_guide_raw_subtype( $post->ID );

    if ( in_array(
        $raw,
        array(
            'lineup',
            'pregame',
            'probable_starter',
            'postgame',
            'game_result',
            'coach_comment',
            'player_comment',
            'farm_result',
            'farm_lineup',
            'farm_player_result',
            'farm',
            'roster_notice',
            'injury_recovery_notice',
            'program_notice',
            'default',
            'default_review',
            'article',
            'notice',
        ),
        true
    ) ) {
        return $raw;
    }

    $haystack = yoshilover_063_normalize_front_density_text( $post->post_title . ' ' . $text );

    if ( 'notice' === $resolved ) {
        if ( preg_match( '/(番組|配信|放送|中継|Hulu|DAZN|BS|CS|地上波)/u', $haystack ) ) {
            return 'program_notice';
        }
        if ( preg_match( '/(復帰|離脱|故障|コンディション|別メニュー|リハビリ)/u', $haystack ) ) {
            return 'injury_recovery_notice';
        }
        if ( preg_match( '/(公示|登録|抹消|昇格|降格|支配下)/u', $haystack ) ) {
            return 'roster_notice';
        }
    }

    if ( 'farm' === $resolved ) {
        if ( preg_match( '/(スタメン|打順)/u', $haystack ) ) {
            return 'farm_lineup';
        }
        if ( preg_match( '/(試合終了|勝利|敗戦|引き分け|結果|スコア)/u', $haystack ) ) {
            return 'farm_result';
        }
        if ( preg_match( '/(若手|育成|支配下|昇格候補|ドラフト)/u', $haystack ) ) {
            return 'farm_player_result';
        }
    }

    if ( 'postgame' === $resolved ) {
        if ( preg_match( '/(監督|阿部監督|コーチ)/u', $haystack ) ) {
            return 'coach_comment';
        }
        if ( preg_match( '/(コメント|談話|語った|語る|振り返った|振り返る)/u', $haystack ) ) {
            return 'player_comment';
        }
        if ( preg_match( '/(試合結果|結果|勝利|敗戦|引き分け|スコア)/u', $haystack ) ) {
            return 'game_result';
        }
    }

    return $resolved;
}

function yoshilover_063_today_giants_guide_section_for_subtype( $subtype ) {
    $map = array(
        'lineup'                 => 'pregame',
        'pregame'                => 'pregame',
        'probable_starter'       => 'pregame',
        'postgame'               => 'postgame',
        'game_result'            => 'postgame',
        'coach_comment'          => 'postgame',
        'player_comment'         => 'postgame',
        'farm_result'            => 'farm',
        'farm_lineup'            => 'farm',
        'farm_player_result'     => 'farm',
        'farm'                   => 'farm',
        'roster_notice'          => 'today_check',
        'injury_recovery_notice' => 'today_check',
        'program_notice'         => 'today_check',
    );

    $key = (string) $subtype;
    return isset( $map[ $key ] ) ? $map[ $key ] : '';
}

function yoshilover_063_is_internal_auto_post_category( $term ) {
    if ( ! ( $term instanceof WP_Term ) ) {
        return false;
    }

    $term_id = (int) $term->term_id;
    $name    = trim( (string) $term->name );
    $slug    = trim( (string) $term->slug );

    return 673 === $term_id
        || '自動投稿' === $name
        || in_array( $slug, array( 'auto-post', 'auto_post' ), true );
}

function yoshilover_063_post_has_hidden_auto_post_category( $post_id ) {
    $terms = get_the_category( (int) $post_id );
    if ( ! is_array( $terms ) || empty( $terms ) ) {
        return false;
    }

    $visible_terms = yoshilover_063_filter_front_category_terms( $terms );
    if ( count( $visible_terms ) !== count( $terms ) ) {
        return true;
    }

    foreach ( $terms as $term ) {
        if ( yoshilover_063_is_internal_auto_post_category( $term ) ) {
            return true;
        }
    }

    return false;
}

function yoshilover_063_build_today_giants_guide_item( $post ) {
    if ( ! ( $post instanceof WP_Post ) || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
        return array();
    }

    $pick = strtolower( trim( (string) get_post_meta( $post->ID, 'today_giants_pick', true ) ) );
    if ( 'hide' === $pick ) {
        return array();
    }

    if ( yoshilover_063_post_has_hidden_auto_post_category( $post->ID ) ) {
        return array();
    }

    $text    = yoshilover_063_front_density_text( $post );
    $subtype = yoshilover_063_resolve_today_giants_guide_subtype( $post, $text );
    if ( in_array( $subtype, array( '', 'default', 'default_review', 'article', 'notice' ), true ) ) {
        return array();
    }

    $label = yoshilover_063_subtype_reader_label( $subtype );
    if ( $label === '' ) {
        return array();
    }

    $title = trim( (string) $post->post_title );
    if ( $title === '' || yoshilover_063_is_weak_title( $title ) ) {
        return array();
    }

    $section = yoshilover_063_today_giants_guide_section_for_subtype( $subtype );
    if ( $section === '' ) {
        return array();
    }

    return array(
        'post_id'    => (int) $post->ID,
        'subtype'    => $subtype,
        'label'      => $label,
        'title'      => $title,
        'url'        => get_permalink( $post ),
        'time'       => yoshilover_063_format_compact_post_time( $post ),
        'timestamp'  => (int) get_post_time( 'U', true, $post ),
        'section'    => $section,
        'pick'       => $pick,
        'is_manual'  => 'main' === $pick,
    );
}

function yoshilover_063_pick_today_giants_main_item( $candidates ) {
    $latest_match = static function( $items, $subtypes = array(), $require_manual = false ) {
        $matched = array();

        foreach ( (array) $items as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            if ( $require_manual && empty( $item['is_manual'] ) ) {
                continue;
            }
            if ( ! empty( $subtypes ) && ! in_array( (string) $item['subtype'], $subtypes, true ) ) {
                continue;
            }
            $matched[] = $item;
        }

        if ( empty( $matched ) ) {
            return array();
        }

        usort(
            $matched,
            function( $left, $right ) {
                return (int) $right['timestamp'] <=> (int) $left['timestamp'];
            }
        );

        return $matched[0];
    };

    $manual = $latest_match( $candidates, array(), true );
    if ( ! empty( $manual ) ) {
        return $manual;
    }

    // today_giants_pick=main があれば既に return 済み。ここからは固定 priority で 1 本選ぶ。
    $priority_groups = array(
        array( 'lineup' ),
        array( 'probable_starter', 'pregame' ),
        array( 'postgame', 'game_result', 'coach_comment', 'player_comment' ),
        array( 'farm_result', 'farm_player_result', 'farm_lineup', 'farm' ),
        array( 'program_notice', 'roster_notice', 'injury_recovery_notice' ),
    );

    foreach ( $priority_groups as $group ) {
        $matched = $latest_match( $candidates, $group );
        if ( ! empty( $matched ) ) {
            return $matched;
        }
    }

    return $latest_match( $candidates );
}

function yoshilover_063_collect_today_giants_guide_sections( $limit_per_section = 3 ) {
    $limit_per_section = max( 1, min( 3, (int) $limit_per_section ) );
    $sections          = array(
        'main_pick'   => array(),
        'pregame'     => array(),
        'postgame'    => array(),
        'farm'        => array(),
        'today_check' => array(),
    );
    $seen_posts        = array();
    $candidates        = array();

    foreach ( yoshilover_063_get_today_giants_box_items( 5 ) as $seed_item ) {
        if ( ! is_array( $seed_item ) ) {
            continue;
        }

        $seed_url = isset( $seed_item['url'] ) ? trim( (string) $seed_item['url'] ) : '';
        $seed_id  = $seed_url !== '' ? (int) url_to_postid( $seed_url ) : 0;
        if ( $seed_id <= 0 || isset( $seen_posts[ $seed_id ] ) ) {
            continue;
        }

        $seed_post = get_post( $seed_id );
        if ( ! ( $seed_post instanceof WP_Post ) ) {
            continue;
        }

        $candidate = yoshilover_063_build_today_giants_guide_item( $seed_post );
        if ( empty( $candidate ) ) {
            continue;
        }

        $candidates[ $seed_id ] = $candidate;
        $seen_posts[ $seed_id ] = true;
    }

    $query = new WP_Query(
        array(
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'posts_per_page'         => 36,
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => true,
        )
    );

    foreach ( $query->posts as $post ) {
        if ( ! ( $post instanceof WP_Post ) || isset( $seen_posts[ $post->ID ] ) ) {
            continue;
        }

        $candidate = yoshilover_063_build_today_giants_guide_item( $post );
        if ( empty( $candidate ) ) {
            continue;
        }

        $candidates[ $post->ID ] = $candidate;
        $seen_posts[ $post->ID ] = true;
    }

    wp_reset_postdata();

    if ( empty( $candidates ) ) {
        return $sections;
    }

    $main_pick = yoshilover_063_pick_today_giants_main_item( array_values( $candidates ) );
    if ( ! empty( $main_pick ) ) {
        $sections['main_pick'][] = $main_pick;
    }

    $used_ids = array();
    if ( ! empty( $main_pick['post_id'] ) ) {
        $used_ids[ (int) $main_pick['post_id'] ] = true;
    }

    $grouped = array(
        'pregame'     => array(),
        'postgame'    => array(),
        'farm'        => array(),
        'today_check' => array(),
    );

    foreach ( $candidates as $candidate ) {
        $section = isset( $candidate['section'] ) ? (string) $candidate['section'] : '';
        if ( isset( $grouped[ $section ] ) ) {
            $grouped[ $section ][] = $candidate;
        }
    }

    foreach ( array_keys( $grouped ) as $section_key ) {
        usort(
            $grouped[ $section_key ],
            function( $left, $right ) {
                return (int) $right['timestamp'] <=> (int) $left['timestamp'];
            }
        );

        foreach ( $grouped[ $section_key ] as $candidate ) {
            $post_id = (int) $candidate['post_id'];
            if ( isset( $used_ids[ $post_id ] ) ) {
                continue;
            }

            $sections[ $section_key ][] = $candidate;
            $used_ids[ $post_id ]       = true;

            if ( count( $sections[ $section_key ] ) >= $limit_per_section ) {
                break;
            }
        }
    }

    return $sections;
}

function yoshilover_063_render_today_giants_fan_guide( $atts = array() ) {
    if ( is_admin() || is_feed() ) {
        return '';
    }
    if ( is_singular( 'post' ) ) {
        return '';
    }
    if ( ! is_front_page() && ! is_home() ) {
        return '';
    }

    static $rendered = false;
    if ( $rendered ) {
        return '';
    }

    $atts = shortcode_atts(
        array(
            'heading'           => '今日の巨人',
            'subheading'        => '今日見る記事を、試合前・試合後・若手でまとめました。',
            'limit_per_section' => 3,
        ),
        $atts,
        'yoshilover_063_today_giants_fan_guide'
    );

    $sections = yoshilover_063_collect_today_giants_guide_sections( (int) $atts['limit_per_section'] );
    $has_rows = false;

    foreach ( $sections as $items ) {
        if ( ! empty( $items ) ) {
            $has_rows = true;
            break;
        }
    }

    if ( ! $has_rows ) {
        return '';
    }

    $rendered = true;

    static $style_rendered = false;
    $style = '';
    if ( ! $style_rendered ) {
        $style  = '<style id="yoshi-front-guide-inline-css">';
        $style .= '.yoshi-today-giants{display:none!important;}';
        $style .= '.yoshi-front-guide{margin:24px 0;padding:22px;border:1px solid #d7dce4;border-radius:20px;background:linear-gradient(180deg,#fffdf8 0%,#ffffff 72%);box-shadow:0 16px 34px rgba(17,24,39,.08);}';
        $style .= '.yoshi-front-guide__eyebrow{display:inline-block;margin:0 0 8px;padding:5px 10px;border-radius:999px;background:#111827;color:#fff;font-size:12px;font-weight:700;letter-spacing:.08em;}';
        $style .= '.yoshi-front-guide__heading{margin:0;font-size:28px;line-height:1.25;color:#111827;}';
        $style .= '.yoshi-front-guide__subheading{margin:10px 0 0;color:#4b5563;font-size:14px;line-height:1.7;}';
        $style .= '.yoshi-front-guide__main,.yoshi-front-guide__section{margin-top:18px;padding:16px;border:1px solid #e5e7eb;border-radius:16px;background:#fff;}';
        $style .= '.yoshi-front-guide__section-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;align-items:start;}';
        $style .= '.yoshi-front-guide__section-title{margin:0 0 12px;font-size:16px;line-height:1.35;color:#111827;}';
        $style .= '.yoshi-front-guide__main-link,.yoshi-front-guide__item-link{display:block;color:inherit;text-decoration:none;}';
        $style .= '.yoshi-front-guide__item-list{margin:0;padding:0;list-style:none;}';
        $style .= '.yoshi-front-guide__item + .yoshi-front-guide__item{margin-top:12px;padding-top:12px;border-top:1px solid #eef2f7;}';
        $style .= '.yoshi-front-guide__meta{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:8px;font-size:12px;color:#6b7280;}';
        $style .= '.yoshi-front-guide__badge{display:inline-flex;align-items:center;padding:4px 9px;border-radius:999px;background:#fff4e6;color:#b45309;font-weight:700;line-height:1.2;}';
        $style .= '.yoshi-front-guide__time{font-variant-numeric:tabular-nums;color:#6b7280;}';
        $style .= '.yoshi-front-guide__title{display:block;font-size:16px;line-height:1.6;color:#111827;font-weight:700;}';
        $style .= '.yoshi-front-guide__main .yoshi-front-guide__title{font-size:20px;line-height:1.5;}';
        $style .= '.yoshi-front-guide__section--today_check .yoshi-front-guide__title{font-size:15px;}';
        $style .= '@media (max-width:782px){.yoshi-front-guide{margin:18px 0;padding:16px;border-radius:16px;}.yoshi-front-guide__heading{font-size:24px;}.yoshi-front-guide__section-grid{grid-template-columns:1fr;gap:12px;}.yoshi-front-guide__main,.yoshi-front-guide__section{margin-top:14px;padding:14px;}.yoshi-front-guide__main .yoshi-front-guide__title{font-size:18px;}}';
        $style .= '</style>';
        $style_rendered = true;
    }

    $render_item = static function( $item, $is_main = false ) {
        $html  = $is_main ? '<a class="yoshi-front-guide__main-link" href="' . esc_url( $item['url'] ) . '">' : '<a class="yoshi-front-guide__item-link" href="' . esc_url( $item['url'] ) . '">';
        $html .= '<span class="yoshi-front-guide__meta">';
        $html .= '<span class="yoshi-front-guide__badge">' . esc_html( $item['label'] ) . '</span>';
        if ( ! empty( $item['time'] ) ) {
            $html .= '<time class="yoshi-front-guide__time">' . esc_html( $item['time'] ) . '</time>';
        }
        $html .= '</span>';
        $html .= '<span class="yoshi-front-guide__title">' . esc_html( $item['title'] ) . '</span>';
        $html .= '</a>';
        return $html;
    };

    $section_labels = array(
        'pregame'     => 'まず見る',
        'postgame'    => '試合後に読む',
        'farm'        => '若手・二軍を追う',
        'today_check' => '今日のチェック',
    );

    $html  = $style;
    $html .= '<section class="yoshi-front-guide" aria-label="今日の巨人ファン観戦ガイド" data-yoshi-phase="246">';
    $html .= '<div class="yoshi-front-guide__head">';
    $html .= '<span class="yoshi-front-guide__eyebrow">' . esc_html( $atts['heading'] ) . '</span>';
    $html .= '<h2 class="yoshi-front-guide__heading">今日の巨人ファン観戦ガイド</h2>';
    $html .= '<p class="yoshi-front-guide__subheading">' . esc_html( $atts['subheading'] ) . '</p>';
    $html .= '</div>';

    if ( ! empty( $sections['main_pick'][0] ) ) {
        $html .= '<article class="yoshi-front-guide__main yoshi-front-guide__main--' . esc_attr( $sections['main_pick'][0]['subtype'] ) . '">';
        $html .= '<h3 class="yoshi-front-guide__section-title">今見る1本</h3>';
        $html .= $render_item( $sections['main_pick'][0], true );
        $html .= '</article>';
    }

    $html .= '<div class="yoshi-front-guide__section-grid">';
    foreach ( $section_labels as $section_key => $section_label ) {
        if ( empty( $sections[ $section_key ] ) ) {
            continue;
        }

        $html .= '<section class="yoshi-front-guide__section yoshi-front-guide__section--' . esc_attr( $section_key ) . '">';
        $html .= '<h3 class="yoshi-front-guide__section-title">' . esc_html( $section_label ) . '</h3>';
        $html .= '<ul class="yoshi-front-guide__item-list">';

        foreach ( $sections[ $section_key ] as $item ) {
            $html .= '<li class="yoshi-front-guide__item yoshi-front-guide__item--' . esc_attr( $item['subtype'] ) . '">';
            $html .= $render_item( $item );
            $html .= '</li>';
        }

        $html .= '</ul>';
        $html .= '</section>';
    }
    $html .= '</div>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_get_sidebar_topic_links( $limit = 4 ) {
    $items = array();
    foreach ( yoshilover_063_get_topic_hub_items() as $item ) {
        $title = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
        $url   = isset( $item['url'] ) ? trim( (string) $item['url'] ) : '';
        if ( $title === '' || $url === '' ) {
            continue;
        }
        $items[] = array(
            'title' => $title,
            'url'   => $url,
            'badge' => isset( $item['badge'] ) ? trim( (string) $item['badge'] ) : '',
        );
        if ( count( $items ) >= $limit ) {
            break;
        }
    }
    return $items;
}

function yoshilover_063_get_sidebar_category_links( $limit = 6 ) {
    $limit      = max( 1, min( 8, (int) $limit ) );
    $categories = get_categories(
        array(
            'hide_empty' => true,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'number'     => $limit + 4,
        )
    );

    $items = array();
    foreach ( $categories as $category ) {
        if ( ! ( $category instanceof WP_Term ) ) {
            continue;
        }

        if (
            in_array( (string) $category->slug, array( 'uncategorized', 'old-articles' ), true )
            || yoshilover_063_is_internal_auto_post_category( $category )
        ) {
            continue;
        }

        $items[] = array(
            'name'  => $category->name,
            'url'   => get_category_link( $category ),
            'count' => (int) $category->count,
            'slug'  => (string) $category->slug,
        );
        if ( count( $items ) >= $limit ) {
            break;
        }
    }

    return $items;
}

function yoshilover_063_get_sidebar_popular_items( $limit = 8 ) {
    $limit = max( 1, min( 10, (int) $limit ) );
    $window_start = strtotime( '-3 days', current_time( 'timestamp' ) );

    $query = new WP_Query(
        array(
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'posts_per_page'         => 24,
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'date_query'             => array(
                array(
                    'after'     => gmdate( 'Y-m-d H:i:s', $window_start ),
                    'inclusive' => true,
                    'column'    => 'post_date_gmt',
                ),
            ),
            'orderby'                => 'date',
            'order'                  => 'DESC',
            'update_post_meta_cache' => true,
            'update_post_term_cache' => true,
        )
    );

    $ranked = array();
    foreach ( $query->posts as $post ) {
        if ( ! ( $post instanceof WP_Post ) ) {
            continue;
        }

        $comment_count = max( 0, (int) $post->comment_count );
        $age_hours     = max( 1, (int) floor( ( current_time( 'timestamp' ) - get_post_timestamp( $post ) ) / HOUR_IN_SECONDS ) );
        $freshness     = max( 1, 72 - $age_hours );
        $score         = ( $comment_count * 10 ) + $freshness;
        $text          = yoshilover_063_front_density_text( $post );
        $subtype       = yoshilover_063_resolve_front_density_subtype( $post, $text );

        $ranked[] = array(
            'score'         => $score,
            'comment_count' => $comment_count,
            'time'          => yoshilover_063_format_compact_post_time( $post ),
            'label'         => yoshilover_063_front_density_subtype_label( $subtype ),
            'subtype'       => $subtype,
            'title'         => trim( (string) $post->post_title ),
            'url'           => get_permalink( $post ),
        );
    }

    wp_reset_postdata();

    usort(
        $ranked,
        function( $a, $b ) {
            if ( $a['score'] === $b['score'] ) {
                return strcmp( (string) $b['time'], (string) $a['time'] );
            }
            return $b['score'] <=> $a['score'];
        }
    );

    return array_slice( $ranked, 0, $limit );
}

function yoshilover_063_render_sidebar_popular_box( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'heading' => '最近3日間の人気記事',
            'limit'   => 8,
        ),
        $atts,
        'yoshilover_sidebar_popular'
    );

    $items = yoshilover_063_get_sidebar_popular_items( (int) $atts['limit'] );
    if ( empty( $items ) ) {
        return '';
    }

    $html  = '<section class="yoshi-sidebar-rail__section yoshi-sidebar-rail__section--popular" aria-label="人気記事" data-yoshi-phase="6">';
    $html .= '<h3 class="yoshi-sidebar-rail__title">' . esc_html( $atts['heading'] ) . '</h3>';
    $html .= '<ol class="yoshi-sidebar-rail__popular-list">';

    foreach ( $items as $index => $item ) {
        $html .= '<li class="yoshi-sidebar-rail__popular-item">';
        $html .= '<a class="yoshi-sidebar-rail__popular-link" href="' . esc_url( $item['url'] ) . '">';
        $html .= '<span class="yoshi-sidebar-rail__popular-rank">' . esc_html( (string) ( $index + 1 ) ) . '</span>';
        $html .= '<span class="yoshi-sidebar-rail__popular-body">';
        $html .= '<span class="yoshi-sidebar-rail__popular-meta">';
        $html .= '<span class="yoshi-sidebar-rail__popular-badge yoshi-sidebar-rail__popular-badge--' . esc_attr( $item['subtype'] ) . '">' . esc_html( $item['label'] ) . '</span>';
        if ( $item['comment_count'] > 0 ) {
            $html .= '<span class="yoshi-sidebar-rail__popular-comments">コメント ' . esc_html( (string) $item['comment_count'] ) . '</span>';
        }
        if ( $item['time'] !== '' ) {
            $html .= '<time class="yoshi-sidebar-rail__popular-time">' . esc_html( $item['time'] ) . '</time>';
        }
        $html .= '</span>';
        $html .= '<span class="yoshi-sidebar-rail__popular-title">' . esc_html( $item['title'] ) . '</span>';
        $html .= '</span>';
        $html .= '</a>';
        $html .= '</li>';
    }

    $html .= '</ol>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_render_today_giants_box( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'heading' => '今日の巨人',
            'limit'   => 5,
        ),
        $atts,
        'yoshilover_today_giants_box'
    );

    $items = yoshilover_063_get_today_giants_box_items( (int) $atts['limit'] );
    if ( empty( $items ) ) {
        return '';
    }

    $html  = '<section class="yoshi-today-giants" aria-label="今日の巨人" data-yoshi-phase="4">';
    $html .= '<div class="yoshi-today-giants__head">';
    $html .= '<h2 class="yoshi-today-giants__heading">' . esc_html( $atts['heading'] ) . '</h2>';
    $html .= '<span class="yoshi-today-giants__note">速報 / 公示 / 話題を右カラムで圧縮表示</span>';
    $html .= '</div>';
    $html .= '<ul class="yoshi-today-giants__list">';

    foreach ( $items as $item ) {
        $html .= '<li class="yoshi-today-giants__item yoshi-today-giants__item--' . esc_attr( $item['subtype'] ) . '">';
        $html .= '<a class="yoshi-today-giants__link" href="' . esc_url( $item['url'] ) . '">';
        $html .= '<span class="yoshi-today-giants__meta">';
        $html .= '<span class="yoshi-today-giants__badge yoshi-today-giants__badge--' . esc_attr( $item['subtype'] ) . '">' . esc_html( $item['label'] ) . '</span>';
        if ( $item['phase'] !== '' ) {
            $html .= '<span class="yoshi-today-giants__chip">' . esc_html( $item['phase'] ) . '</span>';
        }
        if ( $item['score'] !== '' ) {
            $html .= '<span class="yoshi-today-giants__chip yoshi-today-giants__chip--score">' . esc_html( $item['score'] ) . '</span>';
        }
        if ( $item['time'] !== '' ) {
            $html .= '<time class="yoshi-today-giants__time">' . esc_html( $item['time'] ) . '</time>';
        }
        $html .= '</span>';
        $html .= '<span class="yoshi-today-giants__title">' . esc_html( $item['title'] ) . '</span>';
        $html .= '</a>';
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_render_sidebar_rail( $atts = array() ) {
    $today_box   = yoshilover_063_render_today_giants_box();
    $popular_box = yoshilover_063_render_sidebar_popular_box();
    $topics      = yoshilover_063_get_sidebar_topic_links( 4 );
    $categories  = yoshilover_063_get_sidebar_category_links( 6 );

    if ( $today_box === '' && $popular_box === '' && empty( $topics ) && empty( $categories ) ) {
        return '';
    }

    $html  = '<aside class="yoshi-sidebar-rail" aria-label="右カラム導線" data-yoshi-phase="4">';
    if ( $today_box !== '' ) {
        $html .= $today_box;
    }

    if ( $popular_box !== '' ) {
        $html .= $popular_box;
    }

    if ( ! empty( $topics ) ) {
        $html .= '<section class="yoshi-sidebar-rail__section yoshi-sidebar-rail__section--topics" aria-label="注目トピック">';
        $html .= '<h3 class="yoshi-sidebar-rail__title">注目トピック</h3>';
        $html .= '<ul class="yoshi-sidebar-rail__topic-list">';
        foreach ( $topics as $item ) {
            $html .= '<li class="yoshi-sidebar-rail__topic-item">';
            $html .= '<a class="yoshi-sidebar-rail__topic-link" href="' . esc_url( $item['url'] ) . '">';
            if ( $item['badge'] !== '' ) {
                $html .= '<span class="yoshi-sidebar-rail__topic-badge">' . esc_html( $item['badge'] ) . '</span>';
            }
            $html .= '<span class="yoshi-sidebar-rail__topic-title">' . esc_html( $item['title'] ) . '</span>';
            $html .= '</a>';
            $html .= '</li>';
        }
        $html .= '</ul>';
        $html .= '</section>';
    }

    if ( ! empty( $categories ) ) {
        $html .= '<section class="yoshi-sidebar-rail__section yoshi-sidebar-rail__section--categories" aria-label="カテゴリ導線">';
        $html .= '<h3 class="yoshi-sidebar-rail__title">カテゴリ導線</h3>';
        $html .= '<div class="yoshi-sidebar-rail__category-chips">';
        foreach ( $categories as $item ) {
            $html .= '<a class="yoshi-sidebar-rail__category-chip yoshi-sidebar-rail__category-chip--' . esc_attr( $item['slug'] ) . '" href="' . esc_url( $item['url'] ) . '">';
            $html .= '<span class="yoshi-sidebar-rail__category-name">' . esc_html( $item['name'] ) . '</span>';
            $html .= '<span class="yoshi-sidebar-rail__category-count">' . esc_html( (string) $item['count'] ) . '</span>';
            $html .= '</a>';
        }
        $html .= '</div>';
        $html .= '</section>';
    }

    $html .= '</aside>';

    return $html;
}

function yoshilover_063_auto_inject_sidebar_rail( $index, $has_widgets ) {
    static $rendered = false;

    if ( $rendered ) {
        return;
    }
    if ( ! yoshilover_063_should_render_sidebar_rail() ) {
        return;
    }
    if ( ! yoshilover_063_is_primary_sidebar_index( $index ) ) {
        return;
    }

    $rail = yoshilover_063_render_sidebar_rail();
    if ( $rail === '' ) {
        return;
    }

    echo $rail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $rendered = true;
}

function yoshilover_063_render_ad_slot( $slot_id, $extra_classes = '', $args = array() ) {
    $slot_id = sanitize_key( (string) $slot_id );
    if ( $slot_id === '' ) {
        return '';
    }

    $args = wp_parse_args(
        $args,
        array(
            'wrapper'    => 'aside',
            'aria_label' => 'おすすめ導線',
            'label'      => 'PICK UP',
            'title'      => '最新の巨人ニュースをまとめて追う',
            'copy'       => '速報・選手情報・球団ニュースを一覧で確認できます。',
            'url'        => home_url( '/' ),
            'link_label' => '最新記事へ',
        )
    );

    $wrapper = in_array( $args['wrapper'], array( 'aside', 'section', 'div' ), true ) ? $args['wrapper'] : 'div';
    $classes = trim( 'yoshi-ad ' . (string) $extra_classes );

    $html  = '<' . $wrapper . ' class="' . esc_attr( $classes ) . '" data-ad-slot-id="' . esc_attr( $slot_id ) . '" aria-label="' . esc_attr( $args['aria_label'] ) . '">';
    $html .= '<!-- TODO: insert <ins class="adsbygoogle" data-ad-slot="${SLOT_ID}"> -->';
    $html .= '<div class="yoshi-ad__placeholder" aria-hidden="true"></div>';
    $html .= '<div class="yoshi-ad__fallback yoshi-ad-fallback">';
    $html .= '<a class="yoshi-ad__fallback-link" href="' . esc_url( $args['url'] ) . '">';
    $html .= '<span class="yoshi-ad__fallback-label">' . esc_html( $args['label'] ) . '</span>';
    $html .= '<strong class="yoshi-ad__fallback-title">' . esc_html( $args['title'] ) . '</strong>';
    $html .= '<span class="yoshi-ad__fallback-copy">' . esc_html( $args['copy'] ) . '</span>';
    $html .= '<span class="yoshi-ad__fallback-cta">' . esc_html( $args['link_label'] ) . '</span>';
    $html .= '</a>';
    $html .= '</div>';
    $html .= '</' . $wrapper . '>';

    return $html;
}

function yoshilover_063_auto_inject_sidebar_top_ad_slot( $index, $has_widgets ) {
    static $rendered = false;

    if ( $rendered ) {
        return;
    }
    if ( ! yoshilover_063_should_render_sidebar_rail() ) {
        return;
    }
    if ( ! yoshilover_063_is_primary_sidebar_index( $index ) ) {
        return;
    }

    $slot = yoshilover_063_render_ad_slot(
        'sidebar-top',
        'yoshi-ad--sidebar-top',
        array(
            'aria_label' => 'サイドバー上部のおすすめ導線',
            'label'      => 'SIDEBAR PICK',
            'title'      => '最新の巨人ニュースをまとめてチェック',
            'copy'       => '速報・選手情報・公示を右カラムからすぐ追えます。',
            'link_label' => '一覧を見る',
        )
    );

    if ( $slot === '' ) {
        return;
    }

    echo $slot; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    $rendered = true;
}

/* ------------------------------------------------------------
 * 2) 記事下 SNS 反応 block (062 §3 / 063 §2)
 *
 *    公式 X: per-post meta `_yoshilover_x_official_url`
 *    中の人 X: per-post meta `_yoshilover_x_insider_url`
 *
 *    - どちらも絶対 URL、x.com / twitter.com のみ
 *    - 両方空なら空 block を出さない(何も出力しない)
 *    - oEmbed で表示、取得失敗時はリンクフォールバック
 *    - singular post の本文末尾に自動挿入
 *    - shortcode でも手動配置可
 * ---------------------------------------------------------- */

add_shortcode( 'yoshilover_sns_reactions', 'yoshilover_063_render_sns_reactions' );
add_shortcode( 'yoshilover_article_bundles', 'yoshilover_063_render_article_bundles' );
add_shortcode( 'yoshilover_x_follow_cta', 'yoshilover_063_render_x_follow_cta' );
add_shortcode( 'yoshilover_game_today', 'yoshilover_063_render_game_today_shortcode' );
add_shortcode( 'yoshilover_result_panel', 'yoshilover_063_render_result_panel_shortcode' );
add_shortcode( 'yoshilover_lead_info', 'yoshilover_063_render_lead_info_shortcode' );
add_shortcode( 'yoshilover_summary_box', 'yoshilover_063_render_summary_box_shortcode' );
add_shortcode( 'yoshilover_pill', 'yoshilover_063_render_pill_shortcode' );
add_filter( 'the_content', 'yoshilover_063_auto_inject_article_inline_ad_slot', 12 );
add_filter( 'the_content', 'yoshilover_063_auto_inject_sns_reactions', 20 );
add_filter( 'the_content', 'yoshilover_063_auto_inject_article_bundles', 21 );
add_filter( 'the_content', 'yoshilover_063_auto_inject_manual_x_share_corner', 22 );
add_filter( 'the_content', 'yoshilover_063_auto_inject_x_follow_cta', 22 );
add_filter( 'the_content', 'yoshilover_063_auto_inject_article_bottom_ad_slot', 23 );
add_filter( 'the_content', 'yoshilover_063_inject_same_game_articles', 50 );
add_filter( 'the_content', 'yoshilover_063_auto_prepend_meta_line', 5 );

function yoshilover_063_is_singular_post_content_context() {
    if ( is_admin() ) {
        return false;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return false;
    }
    return is_singular( 'post' );
}

function yoshilover_063_insert_html_before_nth_tag( $content, $html, $tag_name, $occurrence ) {
    $content    = (string) $content;
    $html       = (string) $html;
    $tag_name   = trim( (string) $tag_name );
    $occurrence = (int) $occurrence;

    if ( $content === '' || $html === '' || $tag_name === '' || $occurrence <= 0 ) {
        return $content;
    }

    $pattern = '/<' . preg_quote( $tag_name, '/' ) . '\b[^>]*>/i';
    $matches = array();
    if ( ! preg_match_all( $pattern, $content, $matches, PREG_OFFSET_CAPTURE ) ) {
        return $content;
    }
    if ( ! isset( $matches[0][ $occurrence - 1 ][1] ) ) {
        return $content;
    }

    $offset = (int) $matches[0][ $occurrence - 1 ][1];
    return substr( $content, 0, $offset ) . $html . substr( $content, $offset );
}

function yoshilover_063_insert_html_before_first_marker( $content, $html, $markers ) {
    $content = (string) $content;
    $html    = (string) $html;
    $offsets = array();

    if ( $content === '' || $html === '' ) {
        return $content;
    }

    foreach ( (array) $markers as $marker ) {
        $marker = (string) $marker;
        if ( $marker === '' ) {
            continue;
        }
        $offset = strpos( $content, $marker );
        if ( false !== $offset ) {
            $offsets[] = (int) $offset;
        }
    }

    if ( empty( $offsets ) ) {
        return $content . $html;
    }

    $offset = min( $offsets );
    return substr( $content, 0, $offset ) . $html . substr( $content, $offset );
}

function yoshilover_063_auto_inject_article_inline_ad_slot( $content ) {
    if ( ! yoshilover_063_is_singular_post_content_context() ) {
        return $content;
    }

    if ( false !== strpos( (string) $content, 'data-ad-slot-id="article-inline"' ) ) {
        return $content;
    }

    $slot = yoshilover_063_render_ad_slot(
        'article-inline',
        'yoshi-ad--article-inline',
        array(
            'wrapper'    => 'section',
            'aria_label' => '記事途中のおすすめ導線',
            'label'      => 'MORE',
            'title'      => 'このあとも巨人ニュースを続けて追う',
            'copy'       => 'モバイルで同じ流れの関連記事を開きやすい位置に置いています。',
            'link_label' => '関連記事を見る',
        )
    );

    if ( $slot === '' ) {
        return $content;
    }

    return yoshilover_063_insert_html_before_nth_tag( $content, $slot, 'h2', 2 );
}

function yoshilover_063_is_x_url( $url ) {
    if ( ! is_string( $url ) || $url === '' ) {
        return false;
    }
    $host = wp_parse_url( $url, PHP_URL_HOST );
    if ( ! $host ) {
        return false;
    }
    $host = strtolower( $host );
    $ok   = array( 'x.com', 'www.x.com', 'twitter.com', 'www.twitter.com', 'mobile.twitter.com' );
    return in_array( $host, $ok, true );
}

function yoshilover_063_get_sns_reactions_for_post( $post_id ) {
    $post_id = (int) $post_id;
    if ( $post_id <= 0 ) {
        return array();
    }

    $official = trim( (string) get_post_meta( $post_id, '_yoshilover_x_official_url', true ) );
    $insider  = trim( (string) get_post_meta( $post_id, '_yoshilover_x_insider_url',  true ) );

    $reactions = array();
    if ( yoshilover_063_is_x_url( $official ) ) {
        $reactions[] = array(
            'role'  => 'official',
            'label' => '公式 X',
            'url'   => $official,
        );
    }
    if ( yoshilover_063_is_x_url( $insider ) ) {
        $reactions[] = array(
            'role'  => 'insider',
            'label' => '中の人 X',
            'url'   => $insider,
        );
    }
    return $reactions;
}

function yoshilover_063_render_sns_reactions( $atts = array() ) {
    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return '';
    }

    $reactions = yoshilover_063_get_sns_reactions_for_post( $post_id );
    if ( empty( $reactions ) ) {
        return '';
    }

    $html  = '<section class="yoshi-sns-reactions" aria-label="SNS 反応" data-yoshi-phase="1">';
    $html .= '<h3 class="yoshi-sns-reactions__heading">SNS での反応</h3>';
    $html .= '<ul class="yoshi-sns-reactions__list">';

    foreach ( $reactions as $r ) {
        $html .= '<li class="yoshi-sns-reactions__item yoshi-sns-reactions__item--' . esc_attr( $r['role'] ) . '">';
        $html .= '<span class="yoshi-sns-reactions__label">' . esc_html( $r['label'] ) . '</span>';

        $embed = wp_oembed_get( $r['url'] );
        if ( $embed ) {
            $html .= '<div class="yoshi-sns-reactions__embed">' . $embed . '</div>';
        } else {
            $html .= '<a class="yoshi-sns-reactions__fallback" href="' . esc_url( $r['url'] )
                  . '" target="_blank" rel="noopener nofollow">' . esc_html( $r['url'] ) . '</a>';
        }
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_auto_inject_sns_reactions( $content ) {
    if ( is_admin() ) {
        return $content;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return $content;
    }

    // 既に本文中に shortcode 由来の block がある場合は二重出力しない
    if ( strpos( (string) $content, 'yoshi-sns-reactions' ) !== false ) {
        return $content;
    }

    $reactions = yoshilover_063_get_sns_reactions_for_post( $post_id );
    if ( empty( $reactions ) ) {
        return $content;
    }

    return $content . yoshilover_063_render_sns_reactions();
}

function yoshilover_063_render_article_bundles( $atts = array() ) {
    $post = get_post();
    if ( ! ( $post instanceof WP_Post ) || $post->post_type !== 'post' ) {
        return '';
    }

    $groups = yoshilover_063_build_article_bundles_for_post( $post );
    if ( empty( $groups ) ) {
        return '';
    }

    $html  = '<section class="yoshi-article-bundles" aria-label="次に読みたい記事" data-yoshi-phase="3">';
    $html .= '<div class="yoshi-article-bundles__head">';
    $html .= '<h3 class="yoshi-article-bundles__heading">次に読みたい記事</h3>';
    $html .= '<p class="yoshi-article-bundles__lead">同じ試合・同じ選手・同じ話題で続けて追える束だけを出します。</p>';
    $html .= '</div>';
    $html .= '<div class="yoshi-article-bundles__groups">';

    foreach ( $groups as $group ) {
        if ( empty( $group['items'] ) ) {
            continue;
        }
        $html .= '<section class="yoshi-article-bundles__group yoshi-article-bundles__group--' . esc_attr( $group['key'] ) . '">';
        $html .= '<h4 class="yoshi-article-bundles__group-heading">' . esc_html( $group['heading'] ) . '</h4>';
        $html .= '<ul class="yoshi-article-bundles__list">';

        foreach ( $group['items'] as $item ) {
            $html .= '<li class="yoshi-article-bundles__item">';
            $html .= '<a class="yoshi-article-bundles__link" href="' . esc_url( $item['url'] ) . '">';
            $html .= '<span class="yoshi-article-bundles__meta">';
            if ( $item['label'] !== '' ) {
                $html .= '<span class="yoshi-article-bundles__badge yoshi-article-bundles__badge--' . esc_attr( $item['subtype'] ) . '">' . esc_html( $item['label'] ) . '</span>';
            }
            if ( $item['phase'] !== '' ) {
                $html .= '<span class="yoshi-article-bundles__chip">' . esc_html( $item['phase'] ) . '</span>';
            }
            if ( $item['score'] !== '' ) {
                $html .= '<span class="yoshi-article-bundles__chip yoshi-article-bundles__chip--score">' . esc_html( $item['score'] ) . '</span>';
            }
            if ( $item['time'] !== '' ) {
                $html .= '<time class="yoshi-article-bundles__time">' . esc_html( $item['time'] ) . '</time>';
            }
            $html .= '</span>';
            $html .= '<span class="yoshi-article-bundles__title">' . esc_html( $item['title'] ) . '</span>';
            if ( $item['summary'] !== '' ) {
                $html .= '<span class="yoshi-article-bundles__summary">' . esc_html( $item['summary'] ) . '</span>';
            }
            $html .= '</a>';
            $html .= '</li>';
        }

        $html .= '</ul>';
        $html .= '</section>';
    }

    $html .= '</div>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_auto_inject_article_bundles( $content ) {
    if ( is_admin() ) {
        return $content;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }

    $post = get_post();
    if ( ! ( $post instanceof WP_Post ) || $post->post_type !== 'post' ) {
        return $content;
    }

    if ( strpos( (string) $content, 'yoshi-article-bundles' ) !== false ) {
        return $content;
    }

    $bundles = yoshilover_063_render_article_bundles();
    if ( $bundles === '' ) {
        return $content;
    }

    return $content . $bundles;
}

function yoshilover_063_render_same_game_articles_box( $post_id ) {
    if ( ! is_singular( 'post' ) ) {
        return '';
    }

    $items = yoshilover_063_get_same_game_articles( $post_id, 5 );
    if ( empty( $items ) ) {
        return '';
    }

    $style = '<style>
        .yoshi-front-same-game-articles { margin: 24px 0; padding: 16px; background: #f7f7f9; border-radius: 8px; }
        .yoshi-front-same-game-articles__heading { font-size: 16px; font-weight: 700; margin: 0 0 12px; }
        .yoshi-front-same-game-articles__list { list-style: none; padding: 0; margin: 0; }
        .yoshi-front-same-game-articles__item { padding: 8px 0; border-bottom: 1px solid #e5e5e5; }
        .yoshi-front-same-game-articles__item:last-child { border-bottom: 0; }
        .yoshi-front-same-game-articles__label { display: inline-block; padding: 2px 8px; background: #fff; border-radius: 4px; font-size: 12px; margin-right: 8px; }
        .yoshi-front-same-game-articles__time { color: #666; font-size: 12px; margin-right: 8px; }
        .yoshi-front-same-game-articles__title { font-size: 14px; }
        @media (max-width: 480px) {
            .yoshi-front-same-game-articles__item { display: flex; flex-wrap: wrap; gap: 4px 8px; }
        }
    </style>';

    $html  = $style . '<aside class="yoshi-front-same-game-articles" aria-label="この試合の関連記事">';
    $html .= '<h3 class="yoshi-front-same-game-articles__heading">この試合の関連記事</h3>';
    $html .= '<ul class="yoshi-front-same-game-articles__list">';

    foreach ( $items as $item ) {
        $html .= '<li class="yoshi-front-same-game-articles__item">';
        if ( ! empty( $item['subtype_label'] ) ) {
            $html .= '<span class="yoshi-front-same-game-articles__label">' . esc_html( $item['subtype_label'] ) . '</span>';
        }
        $html .= '<span class="yoshi-front-same-game-articles__time">' . esc_html( $item['time'] ) . '</span>';
        $html .= '<a class="yoshi-front-same-game-articles__title" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['title'] ) . '</a>';
        $html .= '</li>';
    }

    $html .= '</ul>';
    $html .= '</aside>';

    return $html;
}

function yoshilover_063_inject_same_game_articles( $content ) {
    if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }

    if ( false !== strpos( (string) $content, 'yoshi-front-same-game-articles' ) ) {
        return $content;
    }

    $box = yoshilover_063_render_same_game_articles_box( get_the_ID() );
    if ( $box === '' ) {
        return $content;
    }

    return $content . $box;
}

/**
 * 記事下の手動 X 投稿シェアコーナー設定。
 *
 * option `yoshilover_063_manual_x_share_corner` で以下キーを受け付ける:
 *   - enabled (bool): default true
 *   - heading (string): default 「この記事を X でシェア」
 *
 * env `YOSHILOVER_063_MANUAL_X_SHARE_CORNER` が設定されている場合は
 * enabled の上書きを優先する。
 */
function yoshilover_063_get_manual_x_share_corner_settings() {
    $defaults = array(
        'enabled' => true,
        'heading' => 'この記事を X でシェア',
        'eyebrow' => 'MANUAL X SHARE',
    );

    $raw = get_option( 'yoshilover_063_manual_x_share_corner', array() );
    if ( ! is_array( $raw ) ) {
        $raw = array();
    }

    $settings = array_merge( $defaults, $raw );
    $env_flag = getenv( 'YOSHILOVER_063_MANUAL_X_SHARE_CORNER' );
    if ( false !== $env_flag && $env_flag !== '' ) {
        $settings['enabled'] = yoshilover_063_parse_env_bool( $env_flag, ! empty( $defaults['enabled'] ) );
    }

    return $settings;
}

function yoshilover_063_parse_env_bool( $value, $default = true ) {
    $value = strtolower( trim( (string) $value ) );
    if ( $value === '' ) {
        return (bool) $default;
    }
    if ( in_array( $value, array( '0', 'false', 'off', 'no', 'disable', 'disabled' ), true ) ) {
        return false;
    }
    if ( in_array( $value, array( '1', 'true', 'on', 'yes', 'enable', 'enabled' ), true ) ) {
        return true;
    }
    return (bool) $default;
}

function yoshilover_063_should_render_manual_x_share_corner() {
    if ( is_admin() ) {
        return false;
    }
    if ( ! is_singular( 'post' ) ) {
        return false;
    }

    $post_id = get_queried_object_id();
    if ( $post_id <= 0 ) {
        return false;
    }
    if ( get_post_status( $post_id ) !== 'publish' ) {
        return false;
    }

    $settings = yoshilover_063_get_manual_x_share_corner_settings();
    return ! empty( $settings['enabled'] );
}

function yoshilover_063_resolve_manual_x_share_subtype( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return 'default';
    }

    $text   = yoshilover_063_front_density_text( $post );
    $type   = strtolower( trim( (string) yoshilover_063_resolve_front_density_subtype( $post, $text ) ) );
    $blob   = yoshilover_063_normalize_front_density_text(
        $post->post_title . ' ' . $text . ' ' .
        implode( ' ', yoshilover_063_get_post_term_names( $post->ID, 'category' ) ) . ' ' .
        implode( ' ', yoshilover_063_get_post_term_names( $post->ID, 'post_tag' ) )
    );
    $mapped = array( 'lineup', 'postgame', 'farm', 'notice', 'program' );

    if ( in_array( $type, $mapped, true ) ) {
        return $type;
    }
    if ( preg_match( '/(program|tv|番組|放送|配信|テレビ)/u', $type . ' ' . $blob ) ) {
        return 'program';
    }

    return 'default';
}

function yoshilover_063_manual_x_share_hashtags( $subtype ) {
    $hashtags = array( '#巨人', '#ジャイアンツ' );
    $extra    = array(
        'lineup'   => '#スタメン',
        'postgame' => '#試合結果',
        'farm'     => '#二軍',
        'notice'   => '#公示',
        'program'  => '#放送予定',
    );

    if ( isset( $extra[ $subtype ] ) ) {
        $hashtags[] = $extra[ $subtype ];
    }

    return implode( ' ', array_values( array_unique( $hashtags ) ) );
}

function yoshilover_063_trim_manual_x_share_text( $text, $limit = 280 ) {
    $text  = yoshilover_063_normalize_front_density_text( $text );
    $limit = max( 40, (int) $limit );

    if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
        if ( mb_strlen( $text, 'UTF-8' ) <= $limit ) {
            return $text;
        }
        return rtrim( mb_substr( $text, 0, $limit - 1, 'UTF-8' ) ) . '…';
    }

    if ( strlen( $text ) <= $limit ) {
        return $text;
    }
    return rtrim( substr( $text, 0, $limit - 1 ) ) . '…';
}

function yoshilover_063_compose_manual_x_share_text( $base, $permalink, $hashtags, $limit = 280 ) {
    $suffix     = yoshilover_063_normalize_front_density_text( trim( $permalink . ' ' . $hashtags ) );
    $suffix_len = function_exists( 'mb_strlen' ) ? mb_strlen( $suffix, 'UTF-8' ) : strlen( $suffix );
    $body_limit = max( 40, (int) $limit - $suffix_len - 1 );
    $body       = yoshilover_063_trim_manual_x_share_text( $base, $body_limit );
    return trim( $body . ' ' . $suffix );
}

function yoshilover_063_render_manual_x_share_pattern_text( $pattern, $subtype, $title, $summary ) {
    $hook_source = $summary !== '' ? $summary : $title;

    $patterns = array(
        'lineup' => array(
            'update' => '巨人のスタメン情報を更新しました。%s',
            'fan'    => 'このスタメン、巨人ファンはどう見る？ %s',
            'focus'  => '試合前に確認したい起用ポイント。%s',
        ),
        'postgame' => array(
            'update'  => '巨人の試合結果を更新しました。%s',
            'fan'     => 'この試合、巨人ファンはどう見る？ %s',
            'recheck' => 'これは試合後にもう一度見たいポイント。%s',
        ),
        'farm' => array(
            'update' => '巨人の二軍情報を更新しました。%s',
            'fan'    => 'この動き、巨人ファンはどう見る？ %s',
            'follow' => '二軍の動きも追っておきたい。%s',
        ),
        'notice' => array(
            'update' => '巨人の公示・選手動向を整理しました。%s',
            'motion' => '公示・選手動向を整理。%s',
            'later'  => '今後の動きも見ながら押さえたい内容。%s',
        ),
        'program' => array(
            'update' => '巨人関連の番組情報を更新しました。%s',
            'fan'    => '巨人ファン目線で押さえておきたい番組。%s',
            'watch'  => '見逃し注意の巨人関連情報です。%s',
        ),
        'default' => array(
            'update' => '巨人ニュースを更新しました。%s',
            'fan'    => 'この話題、巨人ファンはどう見る？ %s',
            'watch'  => '見逃せない巨人ニュース。%s',
        ),
    );

    $template = isset( $patterns[ $subtype ][ $pattern ] ) ? $patterns[ $subtype ][ $pattern ] : '%s';
    $source   = in_array( $pattern, array( 'fan', 'motion', 'later' ), true ) ? $hook_source : $title;
    return sprintf( $template, $source );
}

function yoshilover_063_build_manual_x_share_candidates( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return array();
    }

    $permalink = get_permalink( $post );
    if ( ! is_string( $permalink ) || $permalink === '' ) {
        return array();
    }

    $text        = yoshilover_063_front_density_text( $post );
    $subtype     = yoshilover_063_resolve_manual_x_share_subtype( $post );
    $phase       = yoshilover_063_extract_front_density_phase( $post->post_title . ' ' . $text );
    $summary     = yoshilover_063_build_front_density_summary( $post, $text, $phase );
    $title       = yoshilover_063_normalize_front_density_text( wp_strip_all_tags( get_the_title( $post ), true ) );
    $hashtags    = yoshilover_063_manual_x_share_hashtags( $subtype );
    $definitions = array(
        'lineup' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'fan', 'label' => 'ファン視点' ),
            array( 'key' => 'focus', 'label' => '試合前注目' ),
        ),
        'postgame' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'fan', 'label' => '試合観' ),
            array( 'key' => 'recheck', 'label' => '後で見直し' ),
        ),
        'farm' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'fan', 'label' => 'ファン視点' ),
            array( 'key' => 'follow', 'label' => '動向 follow' ),
        ),
        'notice' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'motion', 'label' => '動向' ),
            array( 'key' => 'later', 'label' => '後効き' ),
        ),
        'program' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'fan', 'label' => 'ファン視点' ),
            array( 'key' => 'watch', 'label' => '見逃し注意' ),
        ),
        'default' => array(
            array( 'key' => 'update', 'label' => '更新' ),
            array( 'key' => 'fan', 'label' => 'ファン視点' ),
            array( 'key' => 'watch', 'label' => '見逃せない' ),
        ),
    );

    if ( $title === '' ) {
        $title = '巨人ニュース';
    }

    $candidates = array();
    foreach ( $definitions[ $subtype ] as $definition ) {
        $base = yoshilover_063_render_manual_x_share_pattern_text(
            $definition['key'],
            $subtype,
            $title,
            $summary
        );
        $text = yoshilover_063_compose_manual_x_share_text(
            $base,
            $permalink,
            $hashtags
        );

        $candidates[] = array(
            'key'        => (string) $definition['key'],
            'label'      => (string) $definition['label'],
            'text'       => $text,
            'intent_url' => 'https://twitter.com/intent/tweet?text=' . rawurlencode( $text ),
        );
    }

    return $candidates;
}

function yoshilover_063_render_manual_x_share_corner( $post_id = 0 ) {
    $settings = yoshilover_063_get_manual_x_share_corner_settings();
    if ( empty( $settings['enabled'] ) ) {
        return '';
    }

    $post = get_post( $post_id ? (int) $post_id : get_the_ID() );
    if ( ! ( $post instanceof WP_Post ) ) {
        return '';
    }
    if ( $post->post_type !== 'post' || $post->post_status !== 'publish' ) {
        return '';
    }

    $subtype    = yoshilover_063_resolve_manual_x_share_subtype( $post );
    $candidates = yoshilover_063_build_manual_x_share_candidates( $post );
    if ( empty( $candidates ) ) {
        return '';
    }

    $title_id  = 'yoshi-x-share-corner-title-' . (int) $post->ID;
    $status_id = 'yoshi-x-share-corner-status-' . (int) $post->ID;
    $html      = '<section class="yoshi-x-share-corner is-yoshi-share-subtype-' . esc_attr( $subtype ) . '" aria-labelledby="' . esc_attr( $title_id ) . '">';
    $html     .= '<div class="yoshi-x-share-corner__header">';
    $html     .= '<span class="yoshi-x-share-corner__eyebrow">' . esc_html( (string) $settings['eyebrow'] ) . '</span>';
    $html     .= '<div id="' . esc_attr( $title_id ) . '" class="yoshi-x-share-corner__title" role="heading" aria-level="2">' . esc_html( (string) $settings['heading'] ) . '</div>';
    $html     .= '<p class="yoshi-x-share-corner__lead">候補をコピーして X に貼り付け、必要なら一言だけ整えて投稿できます。</p>';
    $html     .= '</div>';
    $html     .= '<div class="yoshi-x-share-corner__grid">';

    foreach ( $candidates as $index => $candidate ) {
        $field_id = 'yoshi-x-share-text-' . (int) $post->ID . '-' . (int) $index;
        $html    .= '<article class="yoshi-x-share-corner__card">';
        $html    .= '<div class="yoshi-x-share-corner__meta">';
        $html    .= '<span class="yoshi-x-share-corner__badge">' . esc_html( (string) $candidate['label'] ) . '</span>';
        $html    .= '<span class="yoshi-x-share-corner__subtype">' . esc_html( yoshilover_063_front_density_subtype_label( $subtype ) ) . '</span>';
        $html    .= '</div>';
        $html    .= '<textarea readonly class="yoshi-x-share-corner__text" id="' . esc_attr( $field_id ) . '" rows="5" aria-label="' . esc_attr( 'X投稿候補 ' . (string) $candidate['label'] ) . '">' . esc_textarea( (string) $candidate['text'] ) . '</textarea>';
        $html    .= '<div class="yoshi-x-share-corner__actions">';
        $html    .= '<button type="button" class="yoshi-x-share-corner__copy" data-copy-target="' . esc_attr( $field_id ) . '">コピー</button>';
        $html    .= '<a class="yoshi-x-share-corner__intent" href="' . esc_url( (string) $candidate['intent_url'] ) . '" rel="noopener noreferrer" target="_blank">Xで開く</a>';
        $html    .= '</div>';
        $html    .= '</article>';
    }

    $html .= '</div>';
    $html .= '<p class="yoshi-x-share-corner__status" id="' . esc_attr( $status_id ) . '" aria-live="polite"></p>';
    $html .= '</section>';

    return $html;
}

function yoshilover_063_auto_inject_manual_x_share_corner( $content ) {
    if ( ! yoshilover_063_is_singular_post_content_context() ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return $content;
    }
    if ( get_post_status( $post_id ) !== 'publish' ) {
        return $content;
    }
    if ( strpos( (string) $content, 'yoshi-x-share-corner' ) !== false ) {
        return $content;
    }
    if ( ! yoshilover_063_should_render_manual_x_share_corner() ) {
        return $content;
    }

    $corner = yoshilover_063_render_manual_x_share_corner( $post_id );
    if ( $corner === '' ) {
        return $content;
    }

    return $content . $corner;
}

/**
 * X フォロー CTA block 設定取得。
 *
 * option `yoshilover_063_x_follow_cta` で以下キーを受け付ける:
 *   - enabled (bool): default false (opt-in)
 *   - handle  (string): X のアカウント (既定 yoshilover6760)
 *   - lead    (string): 上部小ラベル (既定 FOLLOW ON X)
 *   - title   (string): メイン訴求文 (既定「最新情報を X で追いかけよう」)
 *   - btn     (string): ボタン文言 (既定 FOLLOW)
 */
function yoshilover_063_get_x_follow_cta_settings() {
    $defaults = array(
        'enabled' => false,
        'handle'  => 'yoshilover6760',
        'lead'    => 'FOLLOW ON X',
        'title'   => '最新情報を X で追いかけよう',
        'btn'     => 'FOLLOW',
    );
    $raw = get_option( 'yoshilover_063_x_follow_cta', array() );
    if ( ! is_array( $raw ) ) {
        $raw = array();
    }
    return array_merge( $defaults, $raw );
}

function yoshilover_063_render_x_follow_cta( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'handle' => '',
            'lead'   => '',
            'title'  => '',
            'btn'    => '',
        ),
        $atts,
        'yoshilover_x_follow_cta'
    );

    $settings = yoshilover_063_get_x_follow_cta_settings();
    $handle   = $atts['handle'] !== '' ? $atts['handle'] : $settings['handle'];
    $lead     = $atts['lead']   !== '' ? $atts['lead']   : $settings['lead'];
    $title    = $atts['title']  !== '' ? $atts['title']  : $settings['title'];
    $btn      = $atts['btn']    !== '' ? $atts['btn']    : $settings['btn'];

    $handle = ltrim( (string) $handle, '@' );
    if ( $handle === '' ) {
        return '';
    }
    $url = 'https://x.com/' . rawurlencode( $handle );

    $html  = '<aside class="yoshi-x-follow-cta" aria-label="X フォロー CTA" data-yoshi-phase="7">';
    $html .= '<span class="yoshi-x-follow-cta__logo" aria-hidden="true">𝕏</span>';
    $html .= '<div class="yoshi-x-follow-cta__body">';
    $html .= '<div class="yoshi-x-follow-cta__lead">' . esc_html( $lead ) . '</div>';
    $html .= '<div class="yoshi-x-follow-cta__title">' . esc_html( $title ) . ' <span style="color:var(--orange);font-weight:700;">@' . esc_html( $handle ) . '</span></div>';
    $html .= '</div>';
    $html .= '<a class="yoshi-x-follow-cta__btn" href="' . esc_url( $url ) . '" rel="noopener" target="_blank">' . esc_html( $btn ) . '</a>';
    $html .= '</aside>';

    return $html;
}

function yoshilover_063_auto_inject_x_follow_cta( $content ) {
    if ( is_admin() ) {
        return $content;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }

    $settings = yoshilover_063_get_x_follow_cta_settings();
    if ( empty( $settings['enabled'] ) ) {
        return $content;
    }

    if ( strpos( (string) $content, 'yoshi-x-follow-cta' ) !== false ) {
        return $content;
    }

    $cta = yoshilover_063_render_x_follow_cta();
    if ( $cta === '' ) {
        return $content;
    }

    return $content . $cta;
}

function yoshilover_063_auto_inject_article_bottom_ad_slot( $content ) {
    if ( ! yoshilover_063_is_singular_post_content_context() ) {
        return $content;
    }

    if ( false !== strpos( (string) $content, 'data-ad-slot-id="article-bottom"' ) ) {
        return $content;
    }

    $slot = yoshilover_063_render_ad_slot(
        'article-bottom',
        'yoshi-ad--article-bottom',
        array(
            'wrapper'    => 'section',
            'aria_label' => '記事下のおすすめ導線',
            'label'      => 'NEXT READ',
            'title'      => '本文の続きとして追いやすい記事をまとめて見る',
            'copy'       => '試合後記事や選手ニュースへ自然に回遊できる導線です。',
            'link_label' => '最新記事を見る',
        )
    );

    if ( $slot === '' ) {
        return $content;
    }

    return yoshilover_063_insert_html_before_first_marker(
        $content,
        $slot,
        array(
            '<section class="yoshi-sns-reactions',
            '<section class="yoshi-article-bundles',
            '<aside class="yoshi-x-follow-cta',
        )
    );
}

/* ------------------------------------------------------------
 * 追加 shortcode (筆者が記事内で自由に埋め込める composable block)
 * ---------------------------------------------------------- */

/**
 * [yoshilover_game_today label="LIVE" title="巨人 vs ヤクルト" time="18:00"]
 */
function yoshilover_063_render_game_today_shortcode( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'label' => 'TODAY',
            'title' => '',
            'time'  => '',
            'logo'  => '⚾',
        ),
        $atts,
        'yoshilover_game_today'
    );
    if ( $atts['title'] === '' ) {
        return '';
    }

    $html  = '<div class="yoshi-game-today" aria-label="本日の試合">';
    $html .= '<div class="yoshi-game-today__logo" aria-hidden="true">' . esc_html( $atts['logo'] ) . '</div>';
    $html .= '<div class="yoshi-game-today__body">';
    $html .= '<div class="yoshi-game-today__label">' . esc_html( $atts['label'] ) . '</div>';
    $html .= '<div class="yoshi-game-today__title">' . esc_html( $atts['title'] ) . '</div>';
    $html .= '</div>';
    if ( $atts['time'] !== '' ) {
        $html .= '<div class="yoshi-game-today__time">' . esc_html( $atts['time'] ) . '</div>';
    }
    $html .= '</div>';
    return $html;
}

/**
 * [yoshilover_result_panel home="巨人" home_score="3" away_score="1" away="阪神" win="巨人勝利"]
 */
function yoshilover_063_render_result_panel_shortcode( $atts = array() ) {
    $atts = shortcode_atts(
        array(
            'home'       => '',
            'away'       => '',
            'home_score' => '',
            'away_score' => '',
            'win'        => '',
        ),
        $atts,
        'yoshilover_result_panel'
    );
    if ( $atts['home'] === '' || $atts['away'] === '' ) {
        return '';
    }

    $html  = '<div class="yoshi-result-panel" aria-label="試合結果">';
    $html .= '<div class="yoshi-result-panel__team -home">' . esc_html( $atts['home'] ) . '</div>';
    $html .= '<div class="yoshi-result-panel__score">';
    $html .= '<span class="yoshi-result-panel__num">' . esc_html( $atts['home_score'] ) . '</span>';
    $html .= '<span class="yoshi-result-panel__sep">-</span>';
    $html .= '<span class="yoshi-result-panel__num">' . esc_html( $atts['away_score'] ) . '</span>';
    $html .= '</div>';
    $html .= '<div class="yoshi-result-panel__team -away">' . esc_html( $atts['away'] ) . '</div>';
    if ( $atts['win'] !== '' ) {
        $html .= '<div class="yoshi-result-panel__win" style="grid-column: 1 / -1;">' . esc_html( $atts['win'] ) . '</div>';
    }
    $html .= '</div>';
    return $html;
}

/**
 * [yoshilover_lead_info]本文[/yoshilover_lead_info]
 */
function yoshilover_063_render_lead_info_shortcode( $atts = array(), $content = '' ) {
    if ( $content === null || $content === '' ) {
        return '';
    }
    return '<div class="yoshi-lead-info">' . do_shortcode( $content ) . '</div>';
}

/**
 * [yoshilover_summary_box]本文[/yoshilover_summary_box]
 */
function yoshilover_063_render_summary_box_shortcode( $atts = array(), $content = '' ) {
    if ( $content === null || $content === '' ) {
        return '';
    }
    return '<div class="yoshi-summary-box">' . do_shortcode( $content ) . '</div>';
}

/**
 * [yoshilover_pill variant="dark"]FOLLOW[/yoshilover_pill]
 */
function yoshilover_063_render_pill_shortcode( $atts = array(), $content = '' ) {
    $atts = shortcode_atts(
        array(
            'variant' => '',
        ),
        $atts,
        'yoshilover_pill'
    );
    if ( $content === null || $content === '' ) {
        return '';
    }
    $classes = 'yoshi-pill';
    if ( in_array( $atts['variant'], array( 'dark', 'outline' ), true ) ) {
        $classes .= ' -' . $atts['variant'];
    }
    return '<span class="' . esc_attr( $classes ) . '">' . esc_html( trim( wp_strip_all_tags( $content ) ) ) . '</span>';
}

/**
 * 読了時間計算 (日本語は 400 chars/min 想定、英数字は単語換算)
 */
function yoshilover_063_estimate_read_minutes( $post_id ) {
    $post_id = (int) $post_id;
    if ( $post_id <= 0 ) {
        return 1;
    }
    $text = (string) get_post_field( 'post_content', $post_id );
    $text = wp_strip_all_tags( $text, true );
    $text = preg_replace( '/\s+/u', '', $text );
    $char_count = mb_strlen( $text, 'UTF-8' );
    if ( $char_count <= 0 ) {
        return 1;
    }
    $minutes = (int) ceil( $char_count / 400 );
    return max( 1, min( 60, $minutes ) );
}

/**
 * .yoshi-meta-line を本文先頭に自動 prepend
 *
 * option `yoshilover_063_meta_line` で制御 (default enabled)
 *   - enabled (bool): default true
 *   - show_read_time (bool): default true
 *   - show_comment_count (bool): default true
 *   - show_date (bool): default true
 */
function yoshilover_063_get_meta_line_settings() {
    $defaults = array(
        'enabled'            => true,
        'show_read_time'     => true,
        'show_comment_count' => true,
        'show_date'          => true,
    );
    $raw = get_option( 'yoshilover_063_meta_line', array() );
    if ( ! is_array( $raw ) ) {
        $raw = array();
    }
    return array_merge( $defaults, $raw );
}

function yoshilover_063_render_meta_line( $post_id ) {
    $settings = yoshilover_063_get_meta_line_settings();
    if ( empty( $settings['enabled'] ) ) {
        return '';
    }
    $post_id = (int) $post_id;
    if ( $post_id <= 0 ) {
        return '';
    }

    $parts = array();

    if ( ! empty( $settings['show_date'] ) ) {
        $date = get_the_date( 'Y.m.d', $post_id );
        if ( $date ) {
            $parts[] = '<span class="-date">' . esc_html( $date ) . '</span>';
        }
    }

    if ( ! empty( $settings['show_read_time'] ) ) {
        $minutes = yoshilover_063_estimate_read_minutes( $post_id );
        $parts[] = '<span class="-read-time">⏱ ' . esc_html( (string) $minutes ) . 'min</span>';
    }

    if ( ! empty( $settings['show_comment_count'] ) ) {
        $comments = (int) get_comments_number( $post_id );
        if ( $comments > 0 ) {
            $parts[] = '<span class="-comment-count">💬 ' . esc_html( (string) $comments ) . '</span>';
        }
    }

    if ( empty( $parts ) ) {
        return '';
    }

    return '<div class="yoshi-meta-line" aria-label="記事メタ" data-yoshi-phase="8">' . implode( '', $parts ) . '</div>';
}

function yoshilover_063_auto_prepend_meta_line( $content ) {
    if ( is_admin() ) {
        return $content;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }

    $post_id = get_the_ID();
    if ( ! $post_id ) {
        return $content;
    }

    if ( strpos( (string) $content, 'yoshi-meta-line' ) !== false ) {
        return $content;
    }

    $line = yoshilover_063_render_meta_line( $post_id );
    if ( $line === '' ) {
        return $content;
    }

    return $line . $content;
}

/* ------------------------------------------------------------
 * 3) Phase 1 noindex (062 §5 / 063 §3)
 *
 *    以下の URL / 文脈を Phase 1 では検索 index から外す:
 *      - topic hub 専用ページ (page meta `_yoshilover_topic_hub_page` = '1')
 *      - コメント pagination (cpage > 0)
 *      - replytocom 付き URL
 *      - comment feed
 *
 *    本体記事 (post) の robots meta は一切触らない。
 *    既存 `yoshilover-post-noindex.php` / SEO プラグインの `wp_robots` filter と
 *    自然に merge させるため wp_head 直接 echo を使わず wp_robots に相乗りする。
 *    これにより `<meta name="robots">` が 1 行に統合される。
 * ---------------------------------------------------------- */

add_filter( 'wp_robots', 'yoshilover_063_phase1_noindex_robots' );
add_action( 'send_headers', 'yoshilover_063_phase1_noindex_headers' );
add_action( 'wp_enqueue_scripts', 'yoshilover_063_enqueue_front_density_assets' );
add_action( 'wp_enqueue_scripts', 'yoshilover_063_enqueue_manual_x_share_corner_assets' );
add_action( 'wp_enqueue_scripts', 'yoshilover_063_enqueue_adsense_scroll_ui_assets' );

function yoshilover_063_phase1_should_noindex() {
    if ( is_admin() ) {
        return false;
    }

    // hub 専用ページ(固定ページ側のフラグで制御)
    if ( is_page() ) {
        $flag = get_post_meta( get_the_ID(), '_yoshilover_topic_hub_page', true );
        if ( $flag === '1' ) {
            return true;
        }
    }

    // コメント pagination
    if ( is_singular() ) {
        $cpage = (int) get_query_var( 'cpage' );
        if ( $cpage > 0 ) {
            return true;
        }
    }

    // replytocom クエリ付き URL
    if ( isset( $_GET['replytocom'] ) && $_GET['replytocom'] !== '' ) {
        return true;
    }

    if ( function_exists( 'is_comment_feed' ) && is_comment_feed() ) {
        return true;
    }

    return false;
}

function yoshilover_063_phase1_noindex_robots( $robots ) {
    if ( ! is_array( $robots ) ) {
        $robots = array();
    }
    if ( ! yoshilover_063_phase1_should_noindex() ) {
        return $robots;
    }
    // 本体記事の index 指定を上書きせず、noindex/follow を足すだけの形にする
    unset( $robots['index'] );
    $robots['noindex'] = true;
    // follow は既存値があれば尊重、無ければ follow を足す(nofollow を上書きしない)
    if ( ! isset( $robots['nofollow'] ) ) {
        $robots['follow'] = true;
    }
    return $robots;
}

function yoshilover_063_phase1_noindex_headers() {
    if ( function_exists( 'is_comment_feed' ) && is_comment_feed() ) {
        header( 'X-Robots-Tag: noindex, follow' );
    }
}

/* ------------------------------------------------------------
 * 4) トップ一覧の情報密度強化 (063-V2)
 *
 *    - front page / posts page の一覧カードにだけ補助 meta を差し込む
 *    - src route / pickup / validator には触らない
 *    - subtype / 試合状況 / 要約 1 行を client-side で安全に後付けする
 * ---------------------------------------------------------- */

function yoshilover_063_should_enhance_front_density() {
    if ( is_admin() ) {
        return false;
    }
    if ( is_feed() || is_singular() ) {
        return false;
    }
    return is_front_page() || is_home();
}

function yoshilover_063_enqueue_front_density_assets() {
    if ( ! yoshilover_063_should_enhance_front_density() ) {
        return;
    }

    $cards = yoshilover_063_build_front_density_cards();
    if ( empty( $cards ) ) {
        return;
    }

    wp_register_script( 'yoshilover-063-front-density', false, array(), '0.7.0', true );
    wp_enqueue_script( 'yoshilover-063-front-density' );

    $payload = array(
        'cards' => $cards,
    );

    $script = <<<'JS'
(() => {
  const config = window.yoshilover063FrontDensity || {};
  const cards = config.cards || {};
  const normalizePath = (href) => {
    try {
      const url = new URL(href, window.location.origin);
      const path = (url.pathname || '').replace(/\/+$/, '');
      return path || '/';
    } catch (error) {
      return href || '';
    }
  };
  const createNode = (tag, className, text) => {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
  };
  const injectCard = (item, meta) => {
    if (!item || !meta || item.dataset.yoshiFrontDensity === '1') {
      return;
    }
    const body = item.querySelector('.p-postList__body');
    const title = body ? body.querySelector('.p-postList__title, .p-postList__ttl, h2') : null;
    if (!body || !title) {
      return;
    }

    const metaRow = document.createElement('div');
    metaRow.className = 'yoshi-front-card__meta';

    if (meta.label) {
      metaRow.appendChild(createNode('span', `yoshi-front-card__badge yoshi-front-card__badge--${meta.subtype || 'generic'}`, meta.label));
    }
    if (meta.phase) {
      metaRow.appendChild(createNode('span', 'yoshi-front-card__chip yoshi-front-card__chip--phase', meta.phase));
    }
    if (meta.score) {
      metaRow.appendChild(createNode('span', 'yoshi-front-card__chip yoshi-front-card__chip--score', meta.score));
    }
    if (meta.comment_count && Number(meta.comment_count) > 0) {
      metaRow.appendChild(createNode('span', 'yoshi-front-card__chip yoshi-front-card__chip--comments yoshi-sidebar-rail__popular-comments', `💬 ${meta.comment_count}`));
    }
    if (meta.primary_player) {
      metaRow.appendChild(createNode('span', 'yoshi-front-card__chip yoshi-front-card__chip--player', meta.primary_player));
    }
    if (meta.read_length_label) {
      metaRow.appendChild(createNode('span', `yoshi-front-card__chip yoshi-front-card__chip--read yoshi-front-card__chip--read-${meta.read_length_tone || 'mid'}`, meta.read_length_label));
    }
    if (meta.chain) {
      metaRow.appendChild(createNode('span', 'yoshi-front-card__chip yoshi-front-card__chip--chain', meta.chain));
    }
    const detailRow = document.createElement('div');
    detailRow.className = 'yoshi-front-card__detail';
    if (meta.is_new) {
      detailRow.appendChild(createNode('span', 'yoshi-front-card__detail-chip yoshi-front-card__detail-chip--new', 'NEW'));
    }
    if (meta.relative_time) {
      detailRow.appendChild(createNode('time', 'yoshi-front-card__detail-chip yoshi-front-card__detail-chip--time', meta.relative_time));
    }
    if (meta.opponent) {
      detailRow.appendChild(createNode('span', 'yoshi-front-card__detail-chip yoshi-front-card__detail-chip--opponent', meta.opponent));
    }
    if (meta.primary_category) {
      detailRow.appendChild(createNode('span', 'yoshi-front-card__detail-chip yoshi-front-card__detail-chip--category', meta.primary_category));
    }
    if (meta.primary_tag) {
      detailRow.appendChild(createNode('span', 'yoshi-front-card__detail-chip yoshi-front-card__detail-chip--tag', meta.primary_tag));
    }
    if (meta.summary) {
      const summary = createNode('p', 'yoshi-front-card__summary', meta.summary);
      title.insertAdjacentElement('afterend', summary);
      if (detailRow.childNodes.length > 0) {
        summary.insertAdjacentElement('afterend', detailRow);
      }
    } else if (detailRow.childNodes.length > 0) {
      title.insertAdjacentElement('afterend', detailRow);
    }
    if (metaRow.childNodes.length > 0) {
      title.insertAdjacentElement('beforebegin', metaRow);
    }

    item.dataset.yoshiFrontDensity = '1';
    item.classList.add('is-yoshi-front-density');
    if (meta.subtype) {
      item.classList.add(`is-yoshi-subtype-${meta.subtype}`);
    }
  };

  document.querySelectorAll('.p-postList__item').forEach((item) => {
    const link = item.querySelector('a[href]');
    if (!link) {
      return;
    }
    const meta = cards[normalizePath(link.href)];
    if (meta) {
      injectCard(item, meta);
    }
  });
})();
JS;

    wp_add_inline_script(
        'yoshilover-063-front-density',
        'window.yoshilover063FrontDensity = ' . wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ';',
        'before'
    );
    wp_add_inline_script( 'yoshilover-063-front-density', $script, 'after' );
}

function yoshilover_063_enqueue_manual_x_share_corner_assets() {
    if ( ! yoshilover_063_should_render_manual_x_share_corner() ) {
        return;
    }

    wp_register_style( 'yoshilover-063-manual-x-share-corner', false, array(), '0.1.0' );
    wp_enqueue_style( 'yoshilover-063-manual-x-share-corner' );

    $styles = <<<'CSS'
.yoshi-x-share-corner {
  --yoshi-share-accent: var(--orange, #F5811F);
  margin: 32px 0 28px;
  padding: 24px;
  border: 1px solid rgba(26, 26, 26, 0.08);
  border-radius: 18px;
  background: linear-gradient(180deg, #fffdf8 0%, #fff8ec 100%);
  box-shadow: 0 16px 34px rgba(26, 26, 26, 0.08);
}
.yoshi-x-share-corner.is-yoshi-share-subtype-lineup { --yoshi-share-accent: #003DA5; }
.yoshi-x-share-corner.is-yoshi-share-subtype-postgame { --yoshi-share-accent: #F5811F; }
.yoshi-x-share-corner.is-yoshi-share-subtype-farm { --yoshi-share-accent: #2E8B57; }
.yoshi-x-share-corner.is-yoshi-share-subtype-notice { --yoshi-share-accent: #D1495B; }
.yoshi-x-share-corner.is-yoshi-share-subtype-program { --yoshi-share-accent: #C08A00; }
.yoshi-x-share-corner.is-yoshi-share-subtype-default { --yoshi-share-accent: #1A1A1A; }
.yoshi-x-share-corner__header {
  margin-bottom: 18px;
}
.yoshi-x-share-corner__eyebrow {
  display: inline-block;
  margin-bottom: 8px;
  color: var(--yoshi-share-accent);
  font-family: 'Oswald', sans-serif;
  font-size: 12px;
  font-weight: 700;
  letter-spacing: 0.16em;
}
.yoshi-x-share-corner__title {
  color: #1A1A1A;
  font-family: 'Oswald', sans-serif;
  font-size: clamp(22px, 2vw, 28px);
  font-weight: 700;
  line-height: 1.15;
  letter-spacing: 0.02em;
}
.yoshi-x-share-corner__lead {
  margin: 10px 0 0;
  color: #4B4B4B;
  font-size: 14px;
  line-height: 1.75;
}
.yoshi-x-share-corner__grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 14px;
}
.yoshi-x-share-corner__card {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 100%;
  padding: 16px;
  border: 1px solid rgba(26, 26, 26, 0.08);
  border-top: 4px solid var(--yoshi-share-accent);
  border-radius: 14px;
  background: #fff;
}
.yoshi-x-share-corner__meta,
.yoshi-x-share-corner__actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  flex-wrap: wrap;
}
.yoshi-x-share-corner__badge,
.yoshi-x-share-corner__subtype {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 700;
  line-height: 1.2;
}
.yoshi-x-share-corner__badge {
  background: var(--yoshi-share-accent);
  color: #fff;
}
.yoshi-x-share-corner__subtype {
  background: rgba(26, 26, 26, 0.06);
  color: #333;
}
.yoshi-x-share-corner__text {
  width: 100%;
  min-height: 10.5em;
  margin: 0;
  padding: 12px 13px;
  border: 1px solid rgba(26, 26, 26, 0.12);
  border-radius: 12px;
  background: #FFFCF7;
  color: #1A1A1A;
  font-size: 14px;
  line-height: 1.7;
  resize: vertical;
}
.yoshi-x-share-corner__copy,
.yoshi-x-share-corner__intent {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 40px;
  border-radius: 999px;
  padding: 0 16px;
  font-family: 'Oswald', sans-serif;
  font-size: 13px;
  font-weight: 700;
  letter-spacing: 0.06em;
  text-decoration: none;
  transition: transform 0.18s ease, box-shadow 0.18s ease, background-color 0.18s ease;
}
.yoshi-x-share-corner__copy {
  border: 0;
  background: #1A1A1A;
  color: #fff;
  cursor: pointer;
}
.yoshi-x-share-corner__intent {
  /* 332-QA-style: subtype に関係なく Giants orange を CTA に使用、
     視認性 + クリック誘導を強化。背景 #F5811F + 文字 #000 (太字) +
     hover/focus で影を強める。subtype-accent は eyebrow / heading で
     既に表現済なので intent button は意図的に統一。 */
  background: #F5811F;
  color: #000;
  font-weight: 800;
  border: 2px solid #000;
  box-shadow: 0 2px 0 rgba(0, 0, 0, 0.18);
}
.yoshi-x-share-corner__copy:hover,
.yoshi-x-share-corner__intent:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 20px rgba(26, 26, 26, 0.14);
  opacity: 0.96;
}
.yoshi-x-share-corner__intent:hover,
.yoshi-x-share-corner__intent:focus-visible {
  background: #FF9F40;
  color: #000;
  box-shadow: 0 6px 18px rgba(245, 129, 31, 0.45), 0 2px 0 #000;
}
.yoshi-x-share-corner__status {
  min-height: 1.4em;
  margin: 12px 0 0;
  color: #4B4B4B;
  font-size: 12px;
  letter-spacing: 0.04em;
}
@media (max-width: 960px) {
  .yoshi-x-share-corner__grid {
    grid-template-columns: 1fr;
  }
}
CSS;
    wp_add_inline_style( 'yoshilover-063-manual-x-share-corner', $styles );

    wp_register_script( 'yoshilover-063-manual-x-share-corner', false, array(), '0.1.0', true );
    wp_enqueue_script( 'yoshilover-063-manual-x-share-corner' );

    $script = <<<'JS'
(() => {
  const resetButton = (button, label) => {
    window.setTimeout(() => {
      button.textContent = label;
      button.disabled = false;
    }, 1800);
  };

  const fallbackCopy = (field) => {
    field.focus();
    field.select();
    field.setSelectionRange(0, field.value.length);
    return document.execCommand('copy');
  };

  document.addEventListener('click', async (event) => {
    const button = event.target.closest('.yoshi-x-share-corner__copy');
    if (!button) {
      return;
    }

    const fieldId = button.getAttribute('data-copy-target');
    const field = fieldId ? document.getElementById(fieldId) : null;
    if (!field) {
      return;
    }

    const corner = button.closest('.yoshi-x-share-corner');
    const status = corner ? corner.querySelector('.yoshi-x-share-corner__status') : null;
    const originalLabel = button.textContent || 'コピー';
    const text = field.value || field.textContent || '';

    button.disabled = true;
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(text);
      } else if (!fallbackCopy(field)) {
        throw new Error('clipboard fallback failed');
      }
      button.textContent = 'コピー済み';
      if (status) {
        status.textContent = 'X投稿候補をコピーしました。';
      }
    } catch (error) {
      button.textContent = '再試行';
      if (status) {
        status.textContent = 'コピーに失敗しました。もう一度押してください。';
      }
    }

    resetButton(button, originalLabel);
  });
})();
JS;
    wp_add_inline_script( 'yoshilover-063-manual-x-share-corner', $script, 'after' );
}

function yoshilover_063_should_render_adsense_scroll_ui() {
    if ( is_admin() || is_feed() || is_search() || is_404() ) {
        return false;
    }

    return is_singular( 'post' );
}

function yoshilover_063_enqueue_adsense_scroll_ui_assets() {
    if ( ! yoshilover_063_should_render_adsense_scroll_ui() ) {
        return;
    }

    wp_register_style( 'yoshilover-063-adsense-scroll-ui', false, array(), '0.2.0' );
    wp_enqueue_style( 'yoshilover-063-adsense-scroll-ui' );

    $styles = <<<'CSS'
.widget_swell_ad_widget.yoshi-adsense-slot {
  position: relative;
  width: 100%;
  margin-right: auto;
  margin-left: auto;
  opacity: 0.86;
  transform: translateY(8px);
  transition: opacity 180ms ease, transform 180ms ease, box-shadow 180ms ease;
  will-change: opacity, transform;
}
.widget_swell_ad_widget.yoshi-adsense-slot.is-yoshi-adsense-inview {
  opacity: 1;
  transform: translateY(0);
}
.widget_swell_ad_widget.yoshi-adsense-slot.is-yoshi-adsense-active {
  opacity: 1;
}
.yoshi-adsense-slot__label {
  display: flex;
  justify-content: center;
  margin: 0 0 6px;
  color: rgba(26, 26, 26, 0.48);
  font-size: 10px;
  line-height: 1.2;
  letter-spacing: 0;
  pointer-events: none;
}
.w-singleBottom .widget_swell_ad_widget.yoshi-adsense-slot,
.w-cta .widget_swell_ad_widget.yoshi-adsense-slot,
.w-beforeRelated .widget_swell_ad_widget.yoshi-adsense-slot,
.w-afterRelated .widget_swell_ad_widget.yoshi-adsense-slot {
  max-width: min(100%, 728px);
  min-height: 96px;
}
#sidebar .widget_swell_ad_widget.yoshi-adsense-slot,
.l-sidebar .widget_swell_ad_widget.yoshi-adsense-slot {
  position: sticky;
  top: 92px;
  z-index: 2;
}
.widget_swell_ad_widget.yoshi-adsense-slot--sidebar.yoshi-adsense-sidewinder-shell {
  box-sizing: border-box;
}
.widget_swell_ad_widget.yoshi-adsense-slot--sidebar.is-yoshi-adsense-sidewinder-fixed,
.widget_swell_ad_widget.yoshi-adsense-slot--sidebar.is-yoshi-adsense-sidewinder-absolute {
  z-index: 6;
  transform: translateY(0) translateZ(0);
  box-shadow: 0 14px 28px rgba(26, 26, 26, 0.12);
}
.yoshi-adsense-sidewinder-placeholder {
  display: block;
  width: 100%;
  pointer-events: none;
}
.widget_swell_ad_widget.yoshi-adsense-slot--before-related,
.widget_swell_ad_widget.yoshi-adsense-slot--after-related {
  margin-top: 22px;
  margin-bottom: 22px;
}
@media (max-width: 960px) {
  #sidebar .widget_swell_ad_widget.yoshi-adsense-slot,
  .l-sidebar .widget_swell_ad_widget.yoshi-adsense-slot {
    position: static;
  }
}
@media (max-width: 768px) {
  .widget_swell_ad_widget.yoshi-adsense-slot {
    transform: translateY(6px);
  }
  .widget_swell_ad_widget.yoshi-adsense-slot--mobile-inline {
    margin-top: 18px;
    margin-bottom: 18px;
    padding: 8px 0;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.94);
    box-shadow: 0 10px 22px rgba(26, 26, 26, 0.08);
    transform: translateY(14px) scale(0.985);
  }
  .widget_swell_ad_widget.yoshi-adsense-slot--mobile-inline.is-yoshi-adsense-inview {
    box-shadow: 0 16px 30px rgba(26, 26, 26, 0.10);
    transform: translateY(0) scale(1);
  }
  .w-singleBottom .widget_swell_ad_widget.yoshi-adsense-slot,
  .w-cta .widget_swell_ad_widget.yoshi-adsense-slot,
  .w-beforeRelated .widget_swell_ad_widget.yoshi-adsense-slot,
  .w-afterRelated .widget_swell_ad_widget.yoshi-adsense-slot {
    max-width: min(100%, 336px);
    min-height: 92px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .widget_swell_ad_widget.yoshi-adsense-slot {
    opacity: 1;
    transform: none;
    transition: none;
  }
}
CSS;

    wp_add_inline_style( 'yoshilover-063-adsense-scroll-ui', $styles );

    wp_register_script( 'yoshilover-063-adsense-scroll-ui', false, array(), '0.2.0', true );
    wp_enqueue_script( 'yoshilover-063-adsense-scroll-ui' );

    $script = <<<'JS'
(() => {
  const doc = document.documentElement;
  const adWidgets = Array.from(document.querySelectorAll('.widget_swell_ad_widget')).filter((widget) => (
    widget.querySelector('ins.adsbygoogle, .adsbygoogle, script[src*="pagead2.googlesyndication.com"]')
  ));

  doc.dataset.yoshiAdsenseSlotCount = String(adWidgets.length);
  doc.dataset.yoshiAdsenseMobileSlotCount = '0';
  doc.dataset.yoshiAdsenseSidewinder = '0';
  if (!adWidgets.length) {
    return;
  }

  const mobileInlineWidgets = [];

  const classify = (widget) => {
    const isSidebar = Boolean(widget.closest('#sidebar, .l-sidebar'));
    if (isSidebar) {
      widget.classList.add('yoshi-adsense-slot--sidebar');
    }
    if (!isSidebar) {
      widget.classList.add('yoshi-adsense-slot--mobile-inline');
      mobileInlineWidgets.push(widget);
    }
    if (widget.closest('.w-singleBottom')) {
      widget.classList.add('yoshi-adsense-slot--single-bottom');
    }
    if (widget.closest('.w-cta')) {
      widget.classList.add('yoshi-adsense-slot--cta');
    }
    if (widget.closest('.w-beforeRelated')) {
      widget.classList.add('yoshi-adsense-slot--before-related');
    }
    if (widget.closest('.w-afterRelated')) {
      widget.classList.add('yoshi-adsense-slot--after-related');
    }
  };

  adWidgets.forEach((widget, index) => {
    widget.classList.add('yoshi-adsense-slot', 'is-yoshi-adsense-waiting');
    widget.dataset.yoshiAdsenseIndex = String(index + 1);
    classify(widget);

    if (!widget.querySelector(':scope > .yoshi-adsense-slot__label')) {
      const label = document.createElement('div');
      label.className = 'yoshi-adsense-slot__label';
      label.textContent = '広告';
      widget.insertBefore(label, widget.firstChild);
    }
  });

  doc.dataset.yoshiAdsenseMobileSlotCount = String(mobileInlineWidgets.length);

  const setupSidewinder = () => {
    if (!window.matchMedia || !window.requestAnimationFrame) {
      return;
    }

    const desktopQuery = window.matchMedia('(min-width: 1100px)');
    const sidewinder = adWidgets.find((widget) => widget.classList.contains('yoshi-adsense-slot--sidebar'));
    const mainContent = document.querySelector('#main_content, .l-mainContent, main, #main');

    if (!desktopQuery || !sidewinder || !mainContent || !sidewinder.parentNode) {
      return;
    }

    doc.dataset.yoshiAdsenseSidewinder = 'ready';
    sidewinder.classList.add('yoshi-adsense-sidewinder-shell');

    const placeholder = document.createElement('div');
    placeholder.className = 'yoshi-adsense-sidewinder-placeholder';
    placeholder.hidden = true;
    sidewinder.parentNode.insertBefore(placeholder, sidewinder);

    let metrics = null;
    let ticking = false;

    const scrollY = () => window.pageYOffset || doc.scrollTop || document.body.scrollTop || 0;
    const scrollX = () => window.pageXOffset || doc.scrollLeft || document.body.scrollLeft || 0;

    const clearModeClasses = () => {
      sidewinder.classList.remove(
        'is-yoshi-adsense-sidewinder-fixed',
        'is-yoshi-adsense-sidewinder-absolute'
      );
    };

    const resetSidewinder = () => {
      clearModeClasses();
      sidewinder.style.position = '';
      sidewinder.style.top = '';
      sidewinder.style.left = '';
      sidewinder.style.width = '';
      placeholder.hidden = true;
      placeholder.style.height = '';
    };

    const measureSidewinder = () => {
      resetSidewinder();
      if (!desktopQuery.matches) {
        metrics = null;
        return;
      }

      const widgetRect = sidewinder.getBoundingClientRect();
      const mainRect = mainContent.getBoundingClientRect();
      const offsetParent = sidewinder.offsetParent || document.body;
      const parentRect = offsetParent.getBoundingClientRect
        ? offsetParent.getBoundingClientRect()
        : { top: 0, left: 0 };
      const pageY = scrollY();
      const pageX = scrollX();
      const height = sidewinder.offsetHeight;
      const mainTop = mainRect.top + pageY;
      const mainBottom = mainRect.bottom + pageY;

      metrics = {
        startTop: widgetRect.top + pageY,
        left: widgetRect.left + pageX,
        width: widgetRect.width,
        height,
        mainTop,
        mainBottom,
        offsetParentTop: parentRect.top + pageY,
        offsetParentLeft: parentRect.left + pageX
      };

      if (!height || (mainBottom - mainTop) <= height + 120) {
        metrics = null;
        resetSidewinder();
      }
    };

    const pinFixed = (top) => {
      placeholder.hidden = false;
      placeholder.style.height = `${metrics.height}px`;
      sidewinder.style.position = 'fixed';
      sidewinder.style.top = `${top}px`;
      sidewinder.style.left = `${metrics.left}px`;
      sidewinder.style.width = `${metrics.width}px`;
      sidewinder.classList.add('is-yoshi-adsense-sidewinder-fixed');
      sidewinder.classList.remove('is-yoshi-adsense-sidewinder-absolute');
    };

    const pinAbsolute = () => {
      placeholder.hidden = false;
      placeholder.style.height = `${metrics.height}px`;
      sidewinder.style.position = 'absolute';
      sidewinder.style.top = `${Math.max(0, metrics.mainBottom - metrics.height - metrics.offsetParentTop)}px`;
      sidewinder.style.left = `${Math.max(0, metrics.left - metrics.offsetParentLeft)}px`;
      sidewinder.style.width = `${metrics.width}px`;
      sidewinder.classList.add('is-yoshi-adsense-sidewinder-absolute');
      sidewinder.classList.remove('is-yoshi-adsense-sidewinder-fixed');
    };

    const updateSidewinder = () => {
      ticking = false;
      if (!desktopQuery.matches || !metrics) {
        resetSidewinder();
        return;
      }

      const fixedTop = 92;
      const pageY = scrollY();
      const fixedStart = metrics.startTop - fixedTop;
      const fixedStop = metrics.mainBottom - metrics.height - fixedTop;

      if (pageY < fixedStart) {
        resetSidewinder();
        return;
      }

      if (pageY >= fixedStop) {
        pinAbsolute();
        return;
      }

      pinFixed(fixedTop);
    };

    const scheduleSidewinder = () => {
      if (ticking) {
        return;
      }
      ticking = true;
      window.requestAnimationFrame(updateSidewinder);
    };

    const remapSidewinder = () => {
      measureSidewinder();
      scheduleSidewinder();
    };

    measureSidewinder();
    scheduleSidewinder();
    window.addEventListener('scroll', scheduleSidewinder, { passive: true });
    window.addEventListener('resize', remapSidewinder, { passive: true });
    window.addEventListener('load', remapSidewinder);
    if (desktopQuery.addEventListener) {
      desktopQuery.addEventListener('change', remapSidewinder);
    }
  };

  setupSidewinder();

  if (!('IntersectionObserver' in window)) {
    adWidgets.forEach((widget) => {
      widget.classList.add('is-yoshi-adsense-inview', 'is-yoshi-adsense-active');
      widget.classList.remove('is-yoshi-adsense-waiting');
    });
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      const widget = entry.target;
      const inView = entry.isIntersecting && entry.intersectionRatio > 0.05;
      widget.classList.toggle('is-yoshi-adsense-inview', inView);
      widget.classList.toggle('is-yoshi-adsense-active', entry.isIntersecting && entry.intersectionRatio >= 0.45);
      widget.classList.remove('is-yoshi-adsense-waiting');
    });
  }, {
    root: null,
    rootMargin: '0px 0px -12% 0px',
    threshold: [0, 0.05, 0.45, 0.75]
  });

  adWidgets.forEach((widget) => observer.observe(widget));
})();
JS;

    wp_add_inline_script( 'yoshilover-063-adsense-scroll-ui', $script, 'after' );
}

function yoshilover_063_build_front_density_cards() {
    global $wp_query;

    $source_posts = array();
    if ( $wp_query instanceof WP_Query && ! empty( $wp_query->posts ) && is_array( $wp_query->posts ) ) {
        foreach ( $wp_query->posts as $post ) {
            if ( $post instanceof WP_Post && $post->post_type === 'post' ) {
                $source_posts[] = $post;
            }
        }
    }

    if ( empty( $source_posts ) ) {
        $fallback_query = new WP_Query(
            array(
                'post_type'           => 'post',
                'post_status'         => 'publish',
                'posts_per_page'      => max( 6, (int) get_option( 'posts_per_page', 10 ) ),
                'ignore_sticky_posts' => true,
                'paged'               => max( 1, (int) get_query_var( 'paged' ) ),
            )
        );
        $source_posts = is_array( $fallback_query->posts ) ? $fallback_query->posts : array();
        wp_reset_postdata();
    }

    if ( empty( $source_posts ) ) {
        return array();
    }

    $cards    = array();
    $contexts = array();

    foreach ( $source_posts as $post ) {
        if ( ! ( $post instanceof WP_Post ) ) {
            continue;
        }

        $card = yoshilover_063_build_front_density_card( $post );
        if ( empty( $card['path'] ) ) {
            continue;
        }

        $path = $card['path'];
        unset( $card['path'] );
        $cards[ $path ] = $card;

        if ( ! empty( $card['context_key'] ) ) {
            $contexts[] = $card['context_key'];
        }
    }

    if ( ! empty( $contexts ) ) {
        $counts = array_count_values( $contexts );
        foreach ( $cards as $path => $card ) {
            $context_key = isset( $card['context_key'] ) ? $card['context_key'] : '';
            $count       = $context_key && isset( $counts[ $context_key ] ) ? (int) $counts[ $context_key ] : 0;
            if ( $count > 1 && isset( $card['subtype'] ) && $card['subtype'] === 'live_update' ) {
                $cards[ $path ]['chain'] = '連投 ' . $count . '本';
            }
        }
    }

    foreach ( array_keys( $cards ) as $path ) {
        unset( $cards[ $path ]['context_key'] );
    }

    return $cards;
}

function yoshilover_063_build_front_density_card( $post ) {
    $path             = yoshilover_063_normalize_front_card_path( get_permalink( $post ) );
    $text             = yoshilover_063_front_density_text( $post );
    $subtype          = yoshilover_063_resolve_front_density_subtype( $post, $text );
    $combined_text    = $post->post_title . ' ' . $text;
    $phase            = yoshilover_063_extract_front_density_phase( $combined_text );
    $score            = yoshilover_063_extract_front_density_score( $combined_text );
    $summary          = yoshilover_063_build_front_density_summary( $post, $text, $phase );
    $categories       = yoshilover_063_get_post_term_names( $post->ID, 'category' );
    $tags             = yoshilover_063_get_post_term_names( $post->ID, 'post_tag' );
    $comment_count    = max( 0, (int) get_comments_number( $post->ID ) );
    $relative_time    = yoshilover_063_format_relative_post_time( $post );
    $compact_time     = yoshilover_063_format_compact_post_time( $post );
    $primary_category = ! empty( $categories[0] ) ? (string) $categories[0] : '';
    $primary_player   = yoshilover_063_front_density_primary_player( $post );
    $primary_tag      = yoshilover_063_front_density_primary_tag( $tags, $primary_player );
    $read_length      = yoshilover_063_front_density_read_length( $post, $subtype );
    $opponent         = yoshilover_063_front_density_extract_opponent( $combined_text );

    return array(
        'path'             => $path,
        'subtype'          => $subtype,
        'label'            => yoshilover_063_front_density_subtype_label( $subtype ),
        'phase'            => $phase,
        'score'            => $score,
        'summary'          => $summary,
        'is_new'           => yoshilover_063_is_recent_post( $post, DAY_IN_SECONDS ),
        'relative_time'    => $relative_time !== '' ? $relative_time : $compact_time,
        'comment_count'    => $comment_count,
        'primary_player'   => $primary_player,
        'read_length_label' => isset( $read_length['label'] ) ? (string) $read_length['label'] : '',
        'read_length_tone' => isset( $read_length['tone'] ) ? (string) $read_length['tone'] : '',
        'primary_category' => $primary_category,
        'primary_tag'      => $primary_tag,
        'opponent'         => $opponent,
        'context_key'      => yoshilover_063_front_density_context_key( $post, $subtype, $combined_text ),
    );
}

function yoshilover_063_normalize_front_card_path( $url ) {
    $path = wp_parse_url( (string) $url, PHP_URL_PATH );
    if ( ! is_string( $path ) || $path === '' ) {
        return '';
    }
    $path = '/' . ltrim( $path, '/' );
    $path = rtrim( $path, '/' );
    return $path === '' ? '/' : $path;
}

function yoshilover_063_front_density_text( $post ) {
    $excerpt = trim( (string) $post->post_excerpt );
    $source  = $excerpt !== '' ? $excerpt : (string) $post->post_content;
    $source  = strip_shortcodes( $source );
    $source  = preg_replace( '/<!--[\s\S]*?-->/', ' ', $source );
    $source  = wp_strip_all_tags( $source, true );
    return yoshilover_063_normalize_front_density_text( $source );
}

function yoshilover_063_front_density_primary_player( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return '';
    }

    $term_groups = array(
        get_the_tags( $post->ID ),
        get_the_category( $post->ID ),
    );

    foreach ( $term_groups as $terms ) {
        if ( ! is_array( $terms ) ) {
            continue;
        }

        foreach ( $terms as $term ) {
            if ( ! ( $term instanceof WP_Term ) ) {
                continue;
            }
            if ( 'category' === (string) $term->taxonomy && yoshilover_063_is_internal_auto_post_category( $term ) ) {
                continue;
            }

            $name = trim( (string) $term->name );
            $slug = trim( (string) $term->slug );
            if ( $name === '' || yoshilover_063_front_density_is_generic_player_term( $name, $slug ) ) {
                continue;
            }
            if ( yoshilover_063_looks_like_player_token( $name ) ) {
                return yoshilover_063_strip_person_suffix( $name );
            }
        }
    }

    return '';
}

function yoshilover_063_front_density_is_generic_player_term( $name, $slug = '' ) {
    $blocked = array(
        'player',
        'players',
        '選手',
        '選手情報',
        '巨人',
        'ジャイアンツ',
        '読売',
        '東京ドーム',
        '試合速報',
        '首脳陣',
        '球団情報',
        'コラム',
        'ドラフト',
        '育成',
        'ドラフト・育成',
        '補強・移籍',
        'ob・解説者',
        'ファーム',
        '二軍',
        '公示',
        'スタメン',
        '予告先発',
    );

    $name_norm = yoshilover_063_normalize_lookup_token( $name );
    $slug_norm = yoshilover_063_normalize_lookup_token( $slug );

    return in_array( $name_norm, $blocked, true ) || in_array( $slug_norm, $blocked, true );
}

function yoshilover_063_front_density_primary_tag( $tags, $primary_player = '' ) {
    $player_norm = yoshilover_063_normalize_lookup_token( yoshilover_063_strip_person_suffix( $primary_player ) );

    foreach ( (array) $tags as $tag ) {
        $tag      = trim( (string) $tag );
        $tag_norm = yoshilover_063_normalize_lookup_token( yoshilover_063_strip_person_suffix( $tag ) );
        if ( $tag === '' ) {
            continue;
        }
        if ( $player_norm !== '' && $tag_norm === $player_norm ) {
            continue;
        }
        return $tag;
    }

    return '';
}

function yoshilover_063_front_density_read_length( $post, $subtype = '' ) {
    if ( (string) $subtype === 'live_update' ) {
        return array(
            'label' => '',
            'tone'  => '',
        );
    }

    $content = wp_strip_all_tags( (string) get_the_content( null, false, $post ), true );
    $content = trim( preg_replace( '/\s+/u', ' ', $content ) );
    $length  = function_exists( 'mb_strlen' ) ? mb_strlen( $content ) : strlen( $content );

    if ( $length < 500 ) {
        return array(
            'label' => '短',
            'tone'  => 'short',
        );
    }
    if ( $length <= 1500 ) {
        return array(
            'label' => '中',
            'tone'  => 'mid',
        );
    }

    return array(
        'label' => '長',
        'tone'  => 'long',
    );
}

function yoshilover_063_normalize_front_density_text( $text ) {
    $text = html_entity_decode( (string) $text, ENT_QUOTES, 'UTF-8' );
    $text = preg_replace( '/[\x{00A0}\s]+/u', ' ', $text );
    $text = preg_replace( '/\s+([、。！？】])/u', '$1', $text );
    $text = preg_replace( '/([【（(])\s+/u', '$1', $text );
    $text = preg_replace( '/\s+(投手|選手|監督)/u', '$1', $text );
    return trim( (string) $text );
}

function yoshilover_063_resolve_front_density_subtype( $post, $text ) {
    $meta_keys = array(
        'article_subtype',
        '_article_subtype',
        'subtype',
        'article_type',
        '_article_type',
    );

    foreach ( $meta_keys as $meta_key ) {
        $value = trim( (string) get_post_meta( $post->ID, $meta_key, true ) );
        if ( $value !== '' ) {
            return yoshilover_063_normalize_front_density_subtype( $value );
        }
    }

    $haystack = yoshilover_063_normalize_front_density_text( $post->post_title . ' ' . $text );

    if ( preg_match( '/(試合終了|サヨナラ|敗戦|勝利|終盤)/u', $haystack ) ) {
        return 'postgame';
    }
    if ( preg_match( '/(回表|回裏|連投|登板|無失点)/u', $haystack ) ) {
        return 'live_update';
    }
    if ( preg_match( '/(スタメン|先発投手|試合開始)/u', $haystack ) ) {
        return 'lineup';
    }
    if ( preg_match( '/(公示|登録|抹消|昇格|降格|合流)/u', $haystack ) ) {
        return 'notice';
    }
    if ( preg_match( '/(予告先発)/u', $haystack ) ) {
        return 'probable_starter';
    }
    if ( preg_match( '/(試合前)/u', $haystack ) ) {
        return 'pregame';
    }
    if ( preg_match( '/(二軍|ファーム)/u', $haystack ) ) {
        return 'farm';
    }
    return 'article';
}

function yoshilover_063_normalize_front_density_subtype( $value ) {
    $value = strtolower( trim( (string) $value ) );
    $value = str_replace( array( '-', ' ' ), '_', $value );

    $map = array(
        'postgame_result'   => 'postgame',
        'live_anchor'       => 'live_update',
        'lineup_notice'     => 'lineup',
        'farm_lineup'       => 'farm',
        'fact_notice'       => 'article',
        'probablestarter'   => 'probable_starter',
        'probable_starter'  => 'probable_starter',
        'notice'            => 'notice',
        'comment_notice'    => 'notice',
        'roster_notice'     => 'notice',
        'transaction'       => 'notice',
    );

    return isset( $map[ $value ] ) ? $map[ $value ] : $value;
}

function yoshilover_063_front_density_subtype_label( $subtype ) {
    $labels = array(
        'live_update'      => '試合中',
        'lineup'           => 'スタメン',
        'postgame'         => '試合後',
        'pregame'          => '試合前',
        'probable_starter' => '予告先発',
        'notice'           => '公示',
        'farm'             => '二軍',
        'article'          => '話題',
    );

    return isset( $labels[ $subtype ] ) ? $labels[ $subtype ] : '話題';
}

function yoshilover_063_extract_front_density_phase( $text ) {
    if ( preg_match( '/【([^】]{1,20})】/u', (string) $text, $matches ) ) {
        return trim( (string) $matches[1] );
    }
    if ( preg_match( '/(試合終了|試合開始|延長\d+回|[一二三四五六七八九十0-9]+回[表裏])/u', (string) $text, $matches ) ) {
        return trim( (string) $matches[1] );
    }
    return '';
}

function yoshilover_063_extract_front_density_score( $text ) {
    if ( preg_match( '/(\d+)\s*[-－]\s*(\d+)/u', (string) $text, $matches ) ) {
        return $matches[1] . '-' . $matches[2];
    }
    return '';
}

function yoshilover_063_build_front_density_summary( $post, $text, $phase ) {
    $summary = trim( (string) $text );

    if ( $phase !== '' ) {
        $summary = preg_replace( '/^【' . preg_quote( $phase, '/' ) . '】/u', '', $summary );
    }
    $summary = preg_replace( '/^📌\s*関連ポスト/u', '', $summary );
    $summary = trim( (string) $summary );

    $sentences = preg_split( '/(?<=[。！？])/u', $summary, -1, PREG_SPLIT_NO_EMPTY );
    if ( is_array( $sentences ) && ! empty( $sentences[0] ) ) {
        $summary = trim( (string) $sentences[0] );
    }

    if ( $summary === '' ) {
        $summary = trim( (string) $post->post_title );
    }

    if ( function_exists( 'mb_strimwidth' ) ) {
        $summary = mb_strimwidth( $summary, 0, 120, '…', 'UTF-8' );
    } else {
        $summary = substr( $summary, 0, 120 );
    }

    return yoshilover_063_normalize_front_density_text( $summary );
}

function yoshilover_063_front_density_context_key( $post, $subtype, $text ) {
    if ( $subtype !== 'live_update' ) {
        return '';
    }

    $opponent = yoshilover_063_front_density_extract_opponent( $text );
    if ( $opponent === '' ) {
        return '';
    }

    return get_the_date( 'Ymd', $post ) . ':' . $subtype . ':' . $opponent;
}

function yoshilover_063_opponent_team_names() {
    return array(
        'ヤクルト',
        '阪神',
        '広島',
        'DeNA',
        '横浜',
        '中日',
        '西武',
        'ソフトバンク',
        '日本ハム',
        'ロッテ',
        'オリックス',
        '楽天',
    );
}

function yoshilover_063_front_density_extract_opponent( $text ) {
    foreach ( yoshilover_063_opponent_team_names() as $team ) {
        if ( false !== mb_strpos( (string) $text, $team ) ) {
            return $team;
        }
    }

    return '';
}

function yoshilover_063_format_compact_post_time( $post ) {
    $timestamp = (int) get_post_time( 'U', true, $post );
    if ( $timestamp <= 0 ) {
        return '';
    }

    $now    = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', true ) : time();
    $format = wp_date( 'Ymd', $timestamp ) === wp_date( 'Ymd', $now ) ? 'H:i' : 'm/d H:i';
    return wp_date( $format, $timestamp );
}

function yoshilover_063_is_recent_post( $post, $window = DAY_IN_SECONDS ) {
    $timestamp = (int) get_post_time( 'U', true, $post );
    if ( $timestamp <= 0 ) {
        return false;
    }

    $now = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', true ) : time();
    return ( $now - $timestamp ) <= (int) $window;
}

function yoshilover_063_format_relative_post_time( $post ) {
    $timestamp = (int) get_post_time( 'U', true, $post );
    if ( $timestamp <= 0 ) {
        return '';
    }

    $now   = function_exists( 'current_time' ) ? (int) current_time( 'timestamp', true ) : time();
    $diff  = max( 0, $now - $timestamp );
    $day   = DAY_IN_SECONDS;
    $hour  = HOUR_IN_SECONDS;
    $min   = MINUTE_IN_SECONDS;

    if ( $diff > $day ) {
        return '';
    }
    if ( $diff < $hour ) {
        $minutes = max( 1, (int) floor( $diff / $min ) );
        return $minutes . '分前';
    }

    $hours = max( 1, (int) floor( $diff / $hour ) );
    return $hours . '時間前';
}

function yoshilover_063_first_non_empty_meta( $post_id, $keys ) {
    foreach ( (array) $keys as $key ) {
        $value = trim( (string) get_post_meta( (int) $post_id, (string) $key, true ) );
        if ( $value !== '' ) {
            return $value;
        }
    }
    return '';
}

function yoshilover_063_is_gameish_subtype( $subtype ) {
    return in_array(
        (string) $subtype,
        array( 'live_update', 'lineup', 'postgame', 'pregame', 'probable_starter', 'farm' ),
        true
    );
}

function yoshilover_063_filter_front_category_terms( $terms ) {
    if ( ! is_array( $terms ) ) {
        return array();
    }

    return array_values(
        array_filter(
            $terms,
            function( $term ) {
                return $term instanceof WP_Term
                    && ! yoshilover_063_is_internal_auto_post_category( $term );
            }
        )
    );
}

/**
 * 表示判定の共通 wrapper. front 系 section / 回遊 / 観戦ガイドで使う統一判定.
 * 既存 helper を内部で組み合わせるだけで、各 helper 自体は変更しない.
 *
 * @param WP_Post $post 判定対象記事
 * @param array   $opts オプション
 * @return bool true なら front 表示 OK、false なら除外
 */
function yoshilover_063_should_show_in_front( $post, $opts = array() ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return false;
    }

    $opts = wp_parse_args(
        is_array( $opts ) ? $opts : array(),
        array(
            'require_gameish' => false,
        )
    );

    $terms = get_the_category( (int) $post->ID );
    if ( is_array( $terms ) && ! empty( $terms ) ) {
        $visible_terms = yoshilover_063_filter_front_category_terms( $terms );
        if ( count( $visible_terms ) !== count( $terms ) ) {
            return false;
        }
    }

    if ( yoshilover_063_post_has_hidden_auto_post_category( $post->ID ) ) {
        return false;
    }

    if ( yoshilover_063_is_weak_title( $post->post_title ) ) {
        return false;
    }

    $subtype     = yoshilover_063_resolve_front_density_subtype( $post, '' );
    $ng_subtypes = array( '', 'default', 'default_review', 'article', 'notice' );
    if ( in_array( $subtype, $ng_subtypes, true ) ) {
        return false;
    }

    if ( ! empty( $opts['require_gameish'] ) && ! yoshilover_063_is_gameish_subtype( $subtype ) ) {
        return false;
    }

    return true;
}

function yoshilover_063_resolve_game_key( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return null;
    }

    $game_id = yoshilover_063_first_non_empty_meta( $post->ID, array( 'game_id', '_game_id' ) );
    if ( $game_id !== '' ) {
        return array(
            'key'    => (string) $game_id,
            'source' => 'meta',
        );
    }

    $blob     = trim( (string) $post->post_title . ' ' . (string) $post->post_excerpt );
    $opponent = yoshilover_063_front_density_extract_opponent( $blob );
    if ( $opponent === '' ) {
        return null;
    }

    return array(
        'key'    => get_the_date( 'Ymd', $post ) . ':' . $opponent,
        'source' => 'pseudo',
    );
}

function yoshilover_063_get_same_game_articles( $post_id, $limit = 5 ) {
    $post_id      = (int) $post_id;
    $limit        = max( 1, (int) $limit );
    $current_post = get_post( $post_id );
    if ( ! ( $current_post instanceof WP_Post ) || $current_post->post_type !== 'post' ) {
        return array();
    }

    $current_text    = yoshilover_063_front_density_text( $current_post );
    $current_subtype = yoshilover_063_resolve_front_density_subtype( $current_post, $current_text );
    if ( ! yoshilover_063_is_gameish_subtype( $current_subtype ) ) {
        return array();
    }

    $game_key = yoshilover_063_resolve_game_key( $current_post );
    if ( ! is_array( $game_key ) || empty( $game_key['key'] ) ) {
        return array();
    }

    $items            = array();
    $current_blob     = trim( (string) $current_post->post_title . ' ' . (string) $current_post->post_excerpt );
    $current_opponent = yoshilover_063_front_density_extract_opponent( $current_blob );
    $current_date_key = get_the_date( 'Ymd', $current_post );

    if ( $game_key['source'] === 'meta' ) {
        $meta_query = new WP_Query(
            array(
                'post_type'              => 'post',
                'post_status'            => 'publish',
                'posts_per_page'         => $limit + 5,
                'post__not_in'           => array( $post_id ),
                'ignore_sticky_posts'    => true,
                'no_found_rows'          => true,
                'update_post_meta_cache' => true,
                'update_post_term_cache' => true,
                'meta_query'             => array(
                    'relation' => 'OR',
                    array(
                        'key'     => 'game_id',
                        'value'   => (string) $game_key['key'],
                        'compare' => '=',
                    ),
                    array(
                        'key'     => '_game_id',
                        'value'   => (string) $game_key['key'],
                        'compare' => '=',
                    ),
                ),
                'orderby'                => 'date',
                'order'                  => 'DESC',
            )
        );

        foreach ( $meta_query->posts as $candidate ) {
            if ( ! ( $candidate instanceof WP_Post ) ) {
                continue;
            }
            $items[ $candidate->ID ] = $candidate;
            if ( count( $items ) >= $limit ) {
                break;
            }
        }
    }

    if (
        count( $items ) < $limit &&
        $current_opponent !== '' &&
        preg_match( '/^(\d{4})(\d{2})(\d{2})$/', (string) $current_date_key, $date_parts )
    ) {
        $date_query = new WP_Query(
            array(
                'post_type'              => 'post',
                'post_status'            => 'publish',
                'posts_per_page'         => $limit + 5,
                'post__not_in'           => array_values(
                    array_unique(
                        array_merge(
                            array( $post_id ),
                            array_map( 'intval', array_keys( $items ) )
                        )
                    )
                ),
                'ignore_sticky_posts'    => true,
                'no_found_rows'          => true,
                'update_post_meta_cache' => true,
                'update_post_term_cache' => true,
                'date_query'             => array(
                    array(
                        'year'  => (int) $date_parts[1],
                        'month' => (int) $date_parts[2],
                        'day'   => (int) $date_parts[3],
                    ),
                ),
                's'                      => $current_opponent,
                'orderby'                => 'date',
                'order'                  => 'DESC',
            )
        );

        foreach ( $date_query->posts as $candidate ) {
            if ( ! ( $candidate instanceof WP_Post ) || isset( $items[ $candidate->ID ] ) ) {
                continue;
            }

            $candidate_blob     = trim( (string) $candidate->post_title . ' ' . (string) $candidate->post_excerpt );
            $candidate_opponent = yoshilover_063_front_density_extract_opponent( $candidate_blob );
            if ( $candidate_opponent !== $current_opponent ) {
                continue;
            }

            $candidate_date_key = get_the_date( 'Ymd', $candidate );
            if ( $candidate_date_key !== $current_date_key ) {
                continue;
            }

            $candidate_game_id = yoshilover_063_first_non_empty_meta( $candidate->ID, array( 'game_id', '_game_id' ) );
            if (
                $game_key['source'] === 'meta' &&
                $candidate_game_id !== '' &&
                $candidate_game_id !== (string) $game_key['key']
            ) {
                continue;
            }

            $items[ $candidate->ID ] = $candidate;
            if ( count( $items ) >= $limit ) {
                break;
            }
        }
    }

    $filtered = array();
    foreach ( $items as $candidate ) {
        $candidate_text = yoshilover_063_front_density_text( $candidate );
        $subtype        = yoshilover_063_resolve_front_density_subtype( $candidate, $candidate_text );
        if ( ! yoshilover_063_is_gameish_subtype( $subtype ) ) {
            continue;
        }

        $terms = wp_get_post_terms( $candidate->ID, 'category' );
        if ( is_wp_error( $terms ) ) {
            $terms = array();
        }
        $filtered_terms = yoshilover_063_filter_front_category_terms( $terms );
        if ( ! empty( $terms ) && empty( $filtered_terms ) ) {
            continue;
        }

        $filtered[] = array(
            'post'          => $candidate,
            'subtype'       => $subtype,
            'subtype_label' => yoshilover_063_subtype_reader_label( $subtype ),
            'time'          => get_the_date( 'H:i', $candidate ),
            'url'           => get_permalink( $candidate ),
            'title'         => get_the_title( $candidate ),
        );
        if ( count( $filtered ) >= $limit ) {
            break;
        }
    }

    return $filtered;
}

function yoshilover_063_get_post_term_names( $post_id, $taxonomy ) {
    $terms = wp_get_post_terms( (int) $post_id, (string) $taxonomy );
    if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
        return array();
    }

    if ( 'category' === (string) $taxonomy ) {
        $terms = array_values(
            array_filter(
                $terms,
                function( $term ) {
                    return $term instanceof WP_Term
                        && ! yoshilover_063_is_internal_auto_post_category( $term );
                }
            )
        );
    }

    $names = array();
    foreach ( $terms as $term ) {
        if ( ! ( $term instanceof WP_Term ) ) {
            continue;
        }
        $name = trim( (string) $term->name );
        if ( $name !== '' ) {
            $names[] = $name;
        }
    }

    return yoshilover_063_unique_tokens( $names );
}

function yoshilover_063_normalize_lookup_token( $token ) {
    $token = trim( (string) $token );
    if ( $token === '' ) {
        return '';
    }
    if ( function_exists( 'mb_strtolower' ) ) {
        return mb_strtolower( $token, 'UTF-8' );
    }
    return strtolower( $token );
}

function yoshilover_063_unique_tokens( $tokens ) {
    $unique = array();
    foreach ( (array) $tokens as $token ) {
        $token = trim( (string) $token );
        $norm  = yoshilover_063_normalize_lookup_token( $token );
        if ( $norm === '' ) {
            continue;
        }
        if ( ! isset( $unique[ $norm ] ) ) {
            $unique[ $norm ] = $token;
        }
    }
    return array_values( $unique );
}

function yoshilover_063_shared_tokens( $left, $right ) {
    $right_map = array();
    foreach ( (array) $right as $token ) {
        $norm = yoshilover_063_normalize_lookup_token( $token );
        if ( $norm !== '' ) {
            $right_map[ $norm ] = trim( (string) $token );
        }
    }

    $shared = array();
    foreach ( (array) $left as $token ) {
        $norm = yoshilover_063_normalize_lookup_token( $token );
        if ( $norm !== '' && isset( $right_map[ $norm ] ) ) {
            $shared[ $norm ] = trim( (string) $token );
        }
    }

    return array_values( $shared );
}

function yoshilover_063_strip_person_suffix( $token ) {
    $token = trim( (string) $token );
    $token = preg_replace( '/(投手|選手|捕手|内野手|外野手)$/u', '', $token );
    return trim( (string) $token );
}

function yoshilover_063_looks_like_player_token( $token ) {
    $token = yoshilover_063_strip_person_suffix( $token );
    if ( $token === '' ) {
        return false;
    }

    $blocked = array_merge(
        array(
            '巨人',
            'ジャイアンツ',
            '読売',
            '東京ドーム',
            'セリーグ',
            'パリーグ',
            'スタメン',
            '予告先発',
            '公示',
            '試合前',
            '試合中',
            '試合後',
        ),
        yoshilover_063_opponent_team_names()
    );

    if ( in_array( $token, $blocked, true ) ) {
        return false;
    }

    return (bool) preg_match(
        "/^(?:[一-龠々]{2,4}|[ァ-ヴー]{2,12}|[A-Za-z][A-Za-z'\\- ]{1,20})$/u",
        $token
    );
}

function yoshilover_063_extract_player_tokens( $text, $tags = array() ) {
    $tokens = array();

    foreach ( (array) $tags as $tag ) {
        if ( yoshilover_063_looks_like_player_token( $tag ) ) {
            $tokens[] = yoshilover_063_strip_person_suffix( $tag );
        }
    }

    if ( preg_match_all( "/((?:[一-龠々]{2,4}|[ァ-ヴー]{2,12}|[A-Za-z][A-Za-z'\\- ]{1,20}))(?:投手|選手|捕手|内野手|外野手)/u", (string) $text, $matches ) ) {
        foreach ( $matches[1] as $match ) {
            if ( yoshilover_063_looks_like_player_token( $match ) ) {
                $tokens[] = yoshilover_063_strip_person_suffix( $match );
            }
        }
    }

    return array_slice( yoshilover_063_unique_tokens( $tokens ), 0, 4 );
}

function yoshilover_063_is_noise_topic_token( $token ) {
    $noise = array(
        'ニュース',
        '話題',
        '記事',
        '速報',
        '巨人',
        'ジャイアンツ',
        '読売',
        '試合速報',
        '未分類',
    );

    return in_array( trim( (string) $token ), $noise, true );
}

function yoshilover_063_extract_topic_tokens( $text, $tags = array(), $subtype = 'article', $player_tokens = array() ) {
    $tokens        = array();
    $player_lookup = array();

    foreach ( (array) $player_tokens as $player_token ) {
        $norm = yoshilover_063_normalize_lookup_token( $player_token );
        if ( $norm !== '' ) {
            $player_lookup[ $norm ] = true;
        }
    }

    $label = yoshilover_063_front_density_subtype_label( $subtype );
    if ( $label !== '' && $label !== '話題' ) {
        $tokens[] = $label;
    }

    foreach ( (array) $tags as $tag ) {
        $tag  = trim( (string) $tag );
        $norm = yoshilover_063_normalize_lookup_token( $tag );
        if ( $tag === '' || isset( $player_lookup[ $norm ] ) || yoshilover_063_is_noise_topic_token( $tag ) ) {
            continue;
        }
        $tokens[] = $tag;
    }

    $patterns = array(
        '/公示|登録|抹消|昇格|降格/u'   => '公示',
        '/予告先発/u'                    => '予告先発',
        '/スタメン/u'                    => 'スタメン',
        '/試合終了|サヨナラ|敗戦|勝利/u' => '試合後',
        '/回表|回裏/u'                    => '試合中',
        '/二軍|ファーム/u'                => '二軍',
        '/本塁打|打点|安打/u'             => '打撃',
        '/先発|登板|無失点|セーブ/u'       => '投手',
        '/故障|離脱|復帰/u'               => 'コンディション',
        '/ドラフト|育成/u'               => 'ドラフト',
    );

    foreach ( $patterns as $pattern => $label_token ) {
        if ( preg_match( $pattern, (string) $text ) ) {
            $tokens[] = $label_token;
        }
    }

    return array_slice( yoshilover_063_unique_tokens( $tokens ), 0, 6 );
}

function yoshilover_063_build_article_context( $post ) {
    if ( ! ( $post instanceof WP_Post ) ) {
        return array();
    }

    $text          = yoshilover_063_front_density_text( $post );
    $blob          = yoshilover_063_normalize_front_density_text( $post->post_title . ' ' . $text );
    $subtype       = yoshilover_063_resolve_front_density_subtype( $post, $text );
    $phase         = yoshilover_063_extract_front_density_phase( $blob );
    $categories    = yoshilover_063_get_post_term_names( $post->ID, 'category' );
    $tags          = yoshilover_063_get_post_term_names( $post->ID, 'post_tag' );
    $player_tokens = yoshilover_063_extract_player_tokens( $blob, $tags );

    return array(
        'id'         => (int) $post->ID,
        'post'       => $post,
        'subtype'    => $subtype,
        'label'      => yoshilover_063_front_density_subtype_label( $subtype ),
        'title'      => trim( (string) $post->post_title ),
        'url'        => get_permalink( $post ),
        'summary'    => yoshilover_063_build_front_density_summary( $post, $text, $phase ),
        'phase'      => $phase,
        'score'      => yoshilover_063_extract_front_density_score( $blob ),
        'time'       => yoshilover_063_format_compact_post_time( $post ),
        'timestamp'  => (int) get_post_time( 'U', true, $post ),
        'date_key'   => get_the_date( 'Ymd', $post ),
        'game_id'    => yoshilover_063_first_non_empty_meta( $post->ID, array( 'game_id', '_game_id' ) ),
        'opponent'   => yoshilover_063_front_density_extract_opponent( $blob ),
        'categories' => $categories,
        'topic_tags' => array_values(
            array_filter(
                $tags,
                function( $tag ) use ( $player_tokens ) {
                    return empty( yoshilover_063_shared_tokens( array( $tag ), $player_tokens ) ) && ! yoshilover_063_is_noise_topic_token( $tag );
                }
            )
        ),
        'players'    => $player_tokens,
        'topics'     => yoshilover_063_extract_topic_tokens( $blob, $tags, $subtype, $player_tokens ),
    );
}

function yoshilover_063_get_article_bundle_candidates( $exclude_post_id ) {
    $query = new WP_Query(
        array(
            'post_type'              => 'post',
            'post_status'            => 'publish',
            'post__not_in'           => array( (int) $exclude_post_id ),
            'posts_per_page'         => 36,
            'ignore_sticky_posts'    => true,
            'no_found_rows'          => true,
            'update_post_meta_cache' => true,
            'update_post_term_cache' => true,
        )
    );

    $contexts = array();
    foreach ( $query->posts as $post ) {
        if ( $post instanceof WP_Post ) {
            $contexts[] = yoshilover_063_build_article_context( $post );
        }
    }

    wp_reset_postdata();

    return $contexts;
}

function yoshilover_063_prepare_article_bundle_item( $context ) {
    return array(
        'post_id'  => (int) $context['id'],
        'url'      => (string) $context['url'],
        'title'    => (string) $context['title'],
        'summary'  => (string) $context['summary'],
        'subtype'  => (string) $context['subtype'],
        'label'    => (string) $context['label'],
        'phase'    => (string) $context['phase'],
        'score'    => (string) $context['score'],
        'time'     => (string) $context['time'],
    );
}

function yoshilover_063_finalize_article_bundle_selection( $ranked, &$used_ids, $limit = 3 ) {
    if ( empty( $ranked ) ) {
        return array();
    }

    usort(
        $ranked,
        function( $left, $right ) {
            if ( $left['score'] === $right['score'] ) {
                return (int) $right['context']['timestamp'] <=> (int) $left['context']['timestamp'];
            }
            return (int) $right['score'] <=> (int) $left['score'];
        }
    );

    $items = array();
    foreach ( $ranked as $row ) {
        $context = $row['context'];
        $post_id = isset( $context['id'] ) ? (int) $context['id'] : 0;
        if ( $post_id <= 0 || isset( $used_ids[ $post_id ] ) ) {
            continue;
        }
        $items[]            = yoshilover_063_prepare_article_bundle_item( $context );
        $used_ids[ $post_id ] = true;
        if ( count( $items ) >= $limit ) {
            break;
        }
    }

    return $items;
}

function yoshilover_063_select_same_game_bundle_items( $context, $candidate_contexts, &$used_ids ) {
    if ( empty( $context['game_id'] ) && ( empty( $context['opponent'] ) || ! yoshilover_063_is_gameish_subtype( $context['subtype'] ) ) ) {
        return array();
    }

    $ranked = array();
    foreach ( $candidate_contexts as $candidate_context ) {
        if ( empty( $candidate_context['id'] ) || isset( $used_ids[ (int) $candidate_context['id'] ] ) ) {
            continue;
        }

        $score = 0;
        if ( $context['game_id'] !== '' && $candidate_context['game_id'] !== '' && $context['game_id'] === $candidate_context['game_id'] ) {
            $score = 100;
        } elseif (
            $context['opponent'] !== '' &&
            $candidate_context['opponent'] === $context['opponent'] &&
            yoshilover_063_is_gameish_subtype( $candidate_context['subtype'] ) &&
            abs( (int) $candidate_context['timestamp'] - (int) $context['timestamp'] ) <= ( DAY_IN_SECONDS * 2 )
        ) {
            $score = 75;
        }

        if ( $score <= 0 ) {
            continue;
        }
        if ( $candidate_context['subtype'] !== $context['subtype'] ) {
            $score += 4;
        }

        $ranked[] = array(
            'score'   => $score,
            'context' => $candidate_context,
        );
    }

    return yoshilover_063_finalize_article_bundle_selection( $ranked, $used_ids, 3 );
}

function yoshilover_063_select_same_player_bundle_items( $context, $candidate_contexts, &$used_ids ) {
    if ( empty( $context['players'] ) ) {
        return array();
    }

    $ranked = array();
    foreach ( $candidate_contexts as $candidate_context ) {
        if ( empty( $candidate_context['id'] ) || isset( $used_ids[ (int) $candidate_context['id'] ] ) ) {
            continue;
        }

        $shared_players = yoshilover_063_shared_tokens( $context['players'], $candidate_context['players'] );
        if ( empty( $shared_players ) ) {
            continue;
        }

        $score = 50 + ( count( $shared_players ) * 12 );
        if ( $candidate_context['subtype'] === $context['subtype'] ) {
            $score += 3;
        }

        $ranked[] = array(
            'score'   => $score,
            'context' => $candidate_context,
        );
    }

    return yoshilover_063_finalize_article_bundle_selection( $ranked, $used_ids, 3 );
}

function yoshilover_063_select_same_topic_bundle_items( $context, $candidate_contexts, &$used_ids ) {
    $ranked = array();
    foreach ( $candidate_contexts as $candidate_context ) {
        if ( empty( $candidate_context['id'] ) || isset( $used_ids[ (int) $candidate_context['id'] ] ) ) {
            continue;
        }

        $shared_topics     = yoshilover_063_shared_tokens( $context['topics'], $candidate_context['topics'] );
        $shared_topic_tags = yoshilover_063_shared_tokens( $context['topic_tags'], $candidate_context['topic_tags'] );
        $shared_categories = yoshilover_063_shared_tokens( $context['categories'], $candidate_context['categories'] );

        $score = ( count( $shared_topics ) * 6 ) + ( count( $shared_topic_tags ) * 4 ) + ( count( $shared_categories ) * 2 );
        if ( $candidate_context['subtype'] === $context['subtype'] ) {
            $score += 2;
        }

        if ( $score <= 0 ) {
            continue;
        }

        $ranked[] = array(
            'score'   => $score,
            'context' => $candidate_context,
        );
    }

    return yoshilover_063_finalize_article_bundle_selection( $ranked, $used_ids, 3 );
}

function yoshilover_063_build_article_bundles_for_post( $post ) {
    $context = yoshilover_063_build_article_context( $post );
    if ( empty( $context ) ) {
        return array();
    }

    $candidate_contexts = yoshilover_063_get_article_bundle_candidates( $post->ID );
    if ( empty( $candidate_contexts ) ) {
        return array();
    }

    $used_ids = array();
    $groups   = array();

    $same_game = yoshilover_063_select_same_game_bundle_items( $context, $candidate_contexts, $used_ids );
    if ( ! empty( $same_game ) ) {
        $groups[] = array(
            'key'     => 'same_game',
            'heading' => '同じ試合',
            'items'   => $same_game,
        );
    }

    $same_player = yoshilover_063_select_same_player_bundle_items( $context, $candidate_contexts, $used_ids );
    if ( ! empty( $same_player ) ) {
        $groups[] = array(
            'key'     => 'same_player',
            'heading' => '同じ選手',
            'items'   => $same_player,
        );
    }

    $same_topic = yoshilover_063_select_same_topic_bundle_items( $context, $candidate_contexts, $used_ids );
    if ( ! empty( $same_topic ) ) {
        $groups[] = array(
            'key'     => 'same_topic',
            'heading' => '同じ話題',
            'items'   => $same_topic,
        );
    }

    return $groups;
}

/* ------------------------------------------------------------
 * 5) deploy / smoke helper (admin only)
 *
 *    live 反映は FTP upload 後に REST 経由で行う。
 *    公開フロントへの影響は manage_options 権限の POST に限定する。
 * ---------------------------------------------------------- */

function yoshilover_063_register_admin_routes() {
    register_rest_route(
        'yoshilover-063/v1',
        '/admin',
        array(
            'methods'             => 'POST',
            'callback'            => 'yoshilover_063_handle_admin_request',
            'permission_callback' => function() {
                return current_user_can( 'manage_options' );
            },
        )
    );
}

function yoshilover_063_handle_admin_request( $request ) {
    $action = sanitize_key( (string) $request->get_param( 'action' ) );

    switch ( $action ) {
        case 'get_theme_mods':
            return yoshilover_063_rest_get_theme_mods( $request );
        case 'search_options':
            return yoshilover_063_rest_search_options( $request );
        case 'set_theme_mod':
            return yoshilover_063_rest_set_theme_mod( $request );
        case 'update_custom_css':
            return yoshilover_063_rest_update_custom_css( $request );
        case 'set_topic_hub_items':
            return yoshilover_063_rest_set_topic_hub_items( $request );
        case 'set_front_top_topic_hub_widget':
            return yoshilover_063_rest_set_front_top_topic_hub_widget( $request );
        case 'set_front_top_widget_stack':
            return yoshilover_063_rest_set_front_top_widget_stack( $request );
        case 'set_post_meta':
            return yoshilover_063_rest_set_post_meta( $request );
        case 'get_post_meta':
            return yoshilover_063_rest_get_post_meta( $request );
        case 'clear_cache':
            return yoshilover_063_rest_clear_cache();
        case 'replace_plugin_php':
            return yoshilover_063_rest_replace_plugin_php( $request );
        default:
            return new WP_Error(
                'yoshilover_063_unknown_action',
                'Unknown action.',
                array( 'status' => 400 )
            );
    }
}

function yoshilover_063_rest_get_theme_mods( $request ) {
    $mods   = get_theme_mods();
    $needle = strtolower( trim( (string) $request->get_param( 'needle' ) ) );

    if ( $needle === '' ) {
        return array(
            'theme' => get_stylesheet(),
            'mods'  => $mods,
        );
    }

    $filtered = array();
    foreach ( $mods as $key => $value ) {
        if ( false !== strpos( strtolower( (string) $key ), $needle ) ) {
            $filtered[ $key ] = $value;
        }
    }

    return array(
        'theme'  => get_stylesheet(),
        'needle' => $needle,
        'mods'   => $filtered,
    );
}

function yoshilover_063_rest_search_options( $request ) {
    $needle = strtolower( trim( (string) $request->get_param( 'needle' ) ) );
    if ( $needle === '' ) {
        return new WP_Error(
            'yoshilover_063_missing_needle',
            'needle is required.',
            array( 'status' => 400 )
        );
    }

    $matches = array();
    foreach ( wp_load_alloptions() as $key => $value ) {
        if ( false === strpos( strtolower( (string) $key ), $needle ) ) {
            continue;
        }
        if ( is_scalar( $value ) || is_null( $value ) ) {
            $preview = (string) $value;
        } else {
            $preview = wp_json_encode( $value );
        }
        $matches[ $key ] = mb_substr( $preview, 0, 500 );
        if ( count( $matches ) >= 100 ) {
            break;
        }
    }

    return array(
        'needle'  => $needle,
        'matches' => $matches,
    );
}

function yoshilover_063_rest_set_theme_mod( $request ) {
    $key = trim( (string) $request->get_param( 'key' ) );
    if ( $key === '' ) {
        return new WP_Error(
            'yoshilover_063_missing_theme_mod_key',
            'key is required.',
            array( 'status' => 400 )
        );
    }

    $value = $request->get_param( 'value' );
    set_theme_mod( $key, $value );

    return array(
        'key'   => $key,
        'value' => get_theme_mod( $key ),
    );
}

function yoshilover_063_rest_update_custom_css( $request ) {
    $css    = trim( (string) $request->get_param( 'css' ) );
    $marker = trim( (string) $request->get_param( 'marker' ) );

    if ( $css === '' ) {
        return new WP_Error(
            'yoshilover_063_missing_css',
            'css is required.',
            array( 'status' => 400 )
        );
    }

    $current = function_exists( 'wp_get_custom_css' ) ? (string) wp_get_custom_css() : '';
    $merged  = yoshilover_063_merge_custom_css( $current, $css, $marker );
    $result  = wp_update_custom_css_post(
        $merged,
        array( 'stylesheet' => get_stylesheet() )
    );

    if ( is_wp_error( $result ) ) {
        return $result;
    }

    return array(
        'css_post_id'     => (int) $result,
        'contains_marker' => ( $marker !== '' && false !== strpos( $merged, $marker ) ),
        'length'          => strlen( $merged ),
    );
}

function yoshilover_063_merge_custom_css( $current, $section, $marker ) {
    $current = (string) $current;
    $section = trim( (string) $section );
    $marker  = trim( (string) $marker );

    if ( $section === '' ) {
        return $current;
    }

    if ( $marker !== '' ) {
        $marker_pos = strpos( $current, $marker );
        if ( false !== $marker_pos ) {
            $header_pos = strrpos( substr( $current, 0, $marker_pos ), '/*' );
            if ( false === $header_pos ) {
                $header_pos = $marker_pos;
            }
            $current = rtrim( substr( $current, 0, $header_pos ) );
        }
    }

    if ( $current === '' ) {
        return $section . "\n";
    }

    return $current . "\n\n" . $section . "\n";
}

function yoshilover_063_rest_set_topic_hub_items( $request ) {
    $items = yoshilover_063_sanitize_topic_hub_items( $request->get_param( 'items' ) );
    update_option( 'yoshilover_topic_hub_items', $items, false );

    return array(
        'count' => count( $items ),
        'items' => get_option( 'yoshilover_topic_hub_items', array() ),
    );
}

function yoshilover_063_extract_shortcode_tag( $shortcode ) {
    if ( preg_match( '/\[([a-z0-9_-]+)/i', (string) $shortcode, $matches ) ) {
        return sanitize_key( (string) $matches[1] );
    }
    return '';
}

function yoshilover_063_upsert_text_widget_shortcode( &$text_widgets, $shortcode ) {
    $widget_id = '';
    $tag       = yoshilover_063_extract_shortcode_tag( $shortcode );

    foreach ( $text_widgets as $number => $widget ) {
        if ( ! is_numeric( $number ) || ! is_array( $widget ) ) {
            continue;
        }
        $text = isset( $widget['text'] ) ? trim( (string) $widget['text'] ) : '';
        if ( $text === $shortcode || ( $tag !== '' && false !== strpos( $text, '[' . $tag ) ) ) {
            $widget_id = 'text-' . $number;
            $text_widgets[ $number ]['title']  = '';
            $text_widgets[ $number ]['text']   = $shortcode;
            $text_widgets[ $number ]['filter'] = true;
            $text_widgets[ $number ]['visual'] = false;
            break;
        }
    }

    if ( $widget_id !== '' ) {
        return $widget_id;
    }

    $max_number = 0;
    foreach ( array_keys( $text_widgets ) as $number ) {
        if ( is_numeric( $number ) ) {
            $max_number = max( $max_number, (int) $number );
        }
    }

    $next_number                  = $max_number + 1;
    $widget_id                    = 'text-' . $next_number;
    $text_widgets[ $next_number ] = array(
        'title'  => '',
        'text'   => $shortcode,
        'filter' => true,
        'visual' => false,
    );

    return $widget_id;
}

function yoshilover_063_ensure_front_top_widget_stack( $shortcodes ) {
    $sidebar_id = 'front_top';
    $sidebars   = get_option( 'sidebars_widgets', array() );
    if ( ! is_array( $sidebars ) ) {
        $sidebars = array();
    }

    $text_widgets = get_option( 'widget_text', array() );
    if ( ! is_array( $text_widgets ) ) {
        $text_widgets = array();
    }

    $shortcodes = array_values(
        array_filter(
            array_map(
                function( $shortcode ) {
                    return trim( (string) $shortcode );
                },
                (array) $shortcodes
            )
        )
    );

    $widget_ids = array();
    foreach ( $shortcodes as $shortcode ) {
        $widget_id = yoshilover_063_upsert_text_widget_shortcode( $text_widgets, $shortcode );
        if ( $widget_id !== '' ) {
            $widget_ids[] = $widget_id;
        }
    }

    update_option( 'widget_text', $text_widgets, false );

    $front_top = array();
    if ( isset( $sidebars[ $sidebar_id ] ) && is_array( $sidebars[ $sidebar_id ] ) ) {
        $front_top = $sidebars[ $sidebar_id ];
    }

    $front_top = array_values(
        array_filter(
            $front_top,
            function( $id ) use ( $widget_ids ) {
                return is_string( $id ) && ! in_array( $id, $widget_ids, true );
            }
        )
    );

    $sidebars[ $sidebar_id ] = array_merge( $widget_ids, $front_top );
    update_option( 'sidebars_widgets', $sidebars, false );

    return array(
        'sidebar'   => $sidebar_id,
        'widgets'   => $sidebars[ $sidebar_id ],
        'widget_ids'=> $widget_ids,
        'instance'  => get_option( 'widget_text', array() ),
    );
}

function yoshilover_063_rest_set_front_top_topic_hub_widget( $request ) {
    $shortcode = trim( (string) $request->get_param( 'shortcode' ) );
    if ( $shortcode === '' ) {
        $shortcode = '[yoshilover_topic_hub]';
    }

    $result              = yoshilover_063_ensure_front_top_widget_stack( array( $shortcode ) );
    $result['widget_id'] = ! empty( $result['widget_ids'][0] ) ? $result['widget_ids'][0] : '';
    return $result;
}

function yoshilover_063_rest_set_front_top_widget_stack( $request ) {
    $shortcodes = $request->get_param( 'shortcodes' );
    if ( ! is_array( $shortcodes ) || empty( $shortcodes ) ) {
        $shortcodes = array(
            '[yoshilover_dense_nav]',
            '[yoshilover_breaking_strip]',
            '[yoshilover_topic_hub]',
        );
    }

    return yoshilover_063_ensure_front_top_widget_stack( $shortcodes );
}

function yoshilover_063_rest_allowed_meta_keys() {
    return array(
        '_yoshilover_x_official_url',
        '_yoshilover_x_insider_url',
        '_yoshilover_topic_hub_page',
    );
}

function yoshilover_063_rest_set_post_meta( $request ) {
    $post_id = absint( $request->get_param( 'post_id' ) );
    $key     = trim( (string) $request->get_param( 'key' ) );
    $delete  = rest_sanitize_boolean( $request->get_param( 'delete' ) );
    $value   = $request->get_param( 'value' );

    if ( $post_id <= 0 || $key === '' ) {
        return new WP_Error(
            'yoshilover_063_missing_meta_target',
            'post_id and key are required.',
            array( 'status' => 400 )
        );
    }

    if ( ! in_array( $key, yoshilover_063_rest_allowed_meta_keys(), true ) ) {
        return new WP_Error(
            'yoshilover_063_meta_key_not_allowed',
            'meta key is not allowed.',
            array( 'status' => 400 )
        );
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return new WP_Error(
            'yoshilover_063_cannot_edit_post',
            'You cannot edit this post.',
            array( 'status' => 403 )
        );
    }

    if ( $delete ) {
        delete_post_meta( $post_id, $key );
        $stored = '';
    } else {
        update_post_meta( $post_id, $key, (string) $value );
        $stored = get_post_meta( $post_id, $key, true );
    }

    return array(
        'post_id' => $post_id,
        'key'     => $key,
        'value'   => $stored,
        'deleted' => $delete,
    );
}

function yoshilover_063_rest_get_post_meta( $request ) {
    $post_id = absint( $request->get_param( 'post_id' ) );
    if ( $post_id <= 0 ) {
        return new WP_Error(
            'yoshilover_063_missing_post_id',
            'post_id is required.',
            array( 'status' => 400 )
        );
    }

    $meta = array();
    foreach ( yoshilover_063_rest_allowed_meta_keys() as $key ) {
        $meta[ $key ] = get_post_meta( $post_id, $key, true );
    }

    return array(
        'post_id' => $post_id,
        'meta'    => $meta,
    );
}

function yoshilover_063_rest_clear_cache() {
    $results = array();

    if ( function_exists( 'rocket_clean_domain' ) ) {
        rocket_clean_domain();
        $results['wp_rocket'] = 'cleared';
    }
    if ( function_exists( 'swell_clear_cache' ) ) {
        swell_clear_cache();
        $results['swell'] = 'cleared';
    }
    if ( function_exists( 'wp_cache_flush' ) ) {
        wp_cache_flush();
        $results['wp_object_cache'] = 'flushed';
    }

    return $results;
}

/**
 * 388: plugin の PHP ファイル本体を REST 経由で書き換える self-update endpoint。
 *
 * WP core が custom plugin の zip upload を REST でサポートしない制約を
 * 回避し、 yoshilover-063 自身を Claude が application password 認証で
 * 書き換えるための endpoint。
 *
 * 制約:
 *   - 書き換え対象は **本 plugin の固定 PHP 1 file のみ** (path 固定、
 *     traversal 不可)
 *   - 認証は permission_callback の `manage_options` で限定
 *   - 旧 file は `.bak` を自動 backup (rollback 用)
 *   - 書き込み失敗で plugin 破壊しないよう atomic rename
 *   - 受信 content は必ず `<?php` で始まる PHP として軽く validate
 *
 * Request body:
 *   - action: replace_plugin_php
 *   - content: 新 PHP 全文 (string)
 *   - expected_version (任意): 新 version 文字列、 一致しなければ reject
 *
 * Response:
 *   - status: ok / error
 *   - written_bytes: int
 *   - backup_path: string
 */
function yoshilover_063_rest_replace_plugin_php( $request ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_forbidden',
            'manage_options capability required.',
            array( 'status' => 403 )
        );
    }

    $content = (string) $request->get_param( 'content' );
    if ( $content === '' ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_empty',
            'content is empty.',
            array( 'status' => 400 )
        );
    }
    if ( substr( ltrim( $content ), 0, 5 ) !== '<?php' ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_invalid',
            'content must start with <?php.',
            array( 'status' => 400 )
        );
    }
    if ( strlen( $content ) > 1024 * 1024 * 2 ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_too_large',
            'content exceeds 2MB limit.',
            array( 'status' => 413 )
        );
    }

    $target = __FILE__;
    if ( ! is_writable( $target ) ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_not_writable',
            'plugin file not writable.',
            array( 'status' => 500 )
        );
    }

    $expected_version = trim( (string) $request->get_param( 'expected_version' ) );
    if ( $expected_version !== '' ) {
        if ( ! preg_match( '/\*\s*Version:\s*([0-9A-Za-z.\-_]+)/', $content, $vm )
            || $vm[1] !== $expected_version ) {
            return new WP_Error(
                'yoshilover_063_replace_plugin_php_version_mismatch',
                'expected_version does not match content header.',
                array( 'status' => 400 )
            );
        }
    }

    $backup = $target . '.bak';
    if ( ! @copy( $target, $backup ) ) {
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_backup_failed',
            'failed to create backup.',
            array( 'status' => 500 )
        );
    }

    $tmp = $target . '.new';
    $bytes = @file_put_contents( $tmp, $content, LOCK_EX );
    if ( $bytes === false || $bytes === 0 ) {
        @unlink( $tmp );
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_write_failed',
            'failed to write tmp file.',
            array( 'status' => 500 )
        );
    }
    if ( ! @rename( $tmp, $target ) ) {
        @unlink( $tmp );
        return new WP_Error(
            'yoshilover_063_replace_plugin_php_rename_failed',
            'failed to atomic-rename tmp to target.',
            array( 'status' => 500 )
        );
    }

    return array(
        'status'        => 'ok',
        'written_bytes' => (int) $bytes,
        'backup_path'   => $backup,
        'target_path'   => $target,
    );
}

/**
 * コメント欄誘導 CTA block 設定取得。
 *
 * option `yoshilover_063_comment_cta` で以下キーを受け付ける:
 *   - enabled (bool):    default true
 *   - lead    (string):  上部誘導文 (default 「この話題、みなさんはどう見ますか？」)
 *   - btn     (string):  ボタン文言 (default 「みんなの意見は？」)
 */
function yoshilover_063_get_comment_cta_settings() {
    $defaults = array(
        'enabled' => true,
        'lead'    => 'この話題、みなさんはどう見ますか？',
        'btn'     => 'みんなの意見は？',
    );
    $raw = get_option( 'yoshilover_063_comment_cta', array() );
    if ( ! is_array( $raw ) ) {
        $raw = array();
    }
    return array_merge( $defaults, $raw );
}

function yoshilover_063_render_comment_cta() {
    $settings = yoshilover_063_get_comment_cta_settings();
    $lead     = (string) $settings['lead'];
    $btn      = (string) $settings['btn'];
    if ( $lead === '' || $btn === '' ) {
        return '';
    }

    $style = '<style id="yoshi-comment-cta-inline-css">'
        . '.yoshi-comment-cta { margin: 28px 0 8px; padding: 14px 16px; background: #fff; border: 1px solid #e8e8ec; border-left: 3px solid var(--orange, #f08300); border-radius: 6px; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 10px 14px; }'
        . '.yoshi-comment-cta__lead { font-size: 14px; line-height: 1.5; color: #333; margin: 0; flex: 1 1 auto; min-width: 0; }'
        . '.yoshi-comment-cta__btn { display: inline-block; padding: 8px 18px; background: var(--orange, #f08300); color: #fff; font-size: 13px; font-weight: 700; text-decoration: none; border-radius: 4px; line-height: 1.3; white-space: nowrap; flex: 0 0 auto; }'
        . '.yoshi-comment-cta__btn:hover, .yoshi-comment-cta__btn:focus { opacity: 0.9; color: #fff; text-decoration: none; }'
        . '@media (max-width: 480px) {'
        . '  .yoshi-comment-cta { padding: 12px 14px; gap: 10px; }'
        . '  .yoshi-comment-cta__lead { font-size: 13px; flex-basis: 100%; }'
        . '  .yoshi-comment-cta__btn { width: 100%; text-align: center; padding: 10px 14px; }'
        . '}'
        . '</style>';

    $html  = $style;
    $html .= '<aside class="yoshi-comment-cta" aria-label="コメント欄への誘導">';
    $html .= '<p class="yoshi-comment-cta__lead">' . esc_html( $lead ) . '</p>';
    $html .= '<a class="yoshi-comment-cta__btn" href="#comments">' . esc_html( $btn ) . '</a>';
    $html .= '</aside>';

    return $html;
}

function yoshilover_063_auto_inject_comment_cta( $content ) {
    if ( is_admin() ) {
        return $content;
    }
    if ( ! in_the_loop() || ! is_main_query() ) {
        return $content;
    }
    if ( ! is_singular( 'post' ) ) {
        return $content;
    }
    if ( ! comments_open( get_the_ID() ) ) {
        return $content;
    }

    $settings = yoshilover_063_get_comment_cta_settings();
    if ( empty( $settings['enabled'] ) ) {
        return $content;
    }

    if ( strpos( (string) $content, 'yoshi-comment-cta' ) !== false ) {
        return $content;
    }

    $cta = yoshilover_063_render_comment_cta();
    if ( $cta === '' ) {
        return $content;
    }

    return $content . $cta;
}
add_filter( 'the_content', 'yoshilover_063_auto_inject_comment_cta', 51 );

/* ============================================================
 * Sidebar widgets (W1: 直近 N 試合 / W3: streak badge)
 *
 * SIDEBAR-WIDGETS-2026-05-08 ticket Phase 1。
 * shortcode で sidebar の Custom HTML widget に貼って使用:
 *   [yoshi_recent_games count="5"]  ← 直近 5 試合 W-L 帯
 *   [yoshi_streak_badge]            ← 連勝/連敗 streak (2 連以上で表示)
 * ============================================================ */

/**
 * 試合速報 category(id=663)の直近 N 件を取得し、W/L を判定。
 *
 * @param int $count 取得件数 (1-20)
 * @return array<int, array{id:int, title:string, url:string, result:string, date:string}>
 *         result: 'W' / 'L' / '-'
 */
function yoshilover_063_get_recent_games_results( $count = 5 ) {
    $count = max( 1, min( 20, intval( $count ) ) );
    $cache_key = 'yoshilover_063_recent_games_' . $count;
    $cached = get_transient( $cache_key );
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $args = array(
        'cat'                    => 663,
        'posts_per_page'         => $count,
        'post_status'            => 'publish',
        'orderby'                => 'date',
        'order'                  => 'DESC',
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    );
    $q = new WP_Query( $args );
    $results = array();
    foreach ( $q->posts as $p ) {
        $title  = get_the_title( $p );
        $result = yoshilover_063_detect_game_result( $title );
        $results[] = array(
            'id'     => (int) $p->ID,
            'title'  => $title,
            'url'    => get_permalink( $p ),
            'result' => $result,
            'date'   => get_the_date( 'n/j', $p ),
        );
    }
    wp_reset_postdata();

    set_transient( $cache_key, $results, 60 * 60 );
    return $results;
}

/**
 * タイトル文字列から試合結果を W / L / - で判定する。
 *
 * 巨人視点での結果を返す。score 表記 + 勝敗 keyword 両方を見る。
 */
function yoshilover_063_detect_game_result( $title ) {
    $title = (string) $title;
    if ( $title === '' ) {
        return '-';
    }
    if ( preg_match( '/勝利|競り勝|サヨナラ勝|逆転勝|完封勝|連勝/u', $title ) ) {
        return 'W';
    }
    if ( preg_match( '/勝ち$|勝つ/u', $title ) ) {
        return 'W';
    }
    if ( preg_match( '/完封負け|敗戦|敗北|連敗|敗れ|黒星|サヨナラ負/u', $title ) ) {
        return 'L';
    }
    if ( preg_match( '/巨人\s*(\d+)\s*[-－—‒‑]\s*(\d+)/u', $title, $m ) ) {
        $a = intval( $m[1] );
        $b = intval( $m[2] );
        if ( $a > $b ) { return 'W'; }
        if ( $a < $b ) { return 'L'; }
        return '-';
    }
    if ( preg_match( '/(\d+)\s*[-－—‒‑]\s*(\d+)\s*巨人/u', $title, $m ) ) {
        $a = intval( $m[1] );
        $b = intval( $m[2] );
        if ( $a < $b ) { return 'W'; }
        if ( $a > $b ) { return 'L'; }
        return '-';
    }
    return '-';
}

/**
 * 直近 N 試合 widget の HTML を生成。
 *
 * shortcode: [yoshi_recent_games count="5"]
 */
function yoshilover_063_render_recent_games_widget( $atts ) {
    $atts  = shortcode_atts( array( 'count' => 5 ), $atts, 'yoshi_recent_games' );
    $count = max( 1, min( 10, intval( $atts['count'] ) ) );
    $games = yoshilover_063_get_recent_games_results( $count );
    if ( empty( $games ) ) {
        return '';
    }

    $style = '<style id="yoshi-recent-games-inline-css">'
        . '.yoshi-recent-games { margin: 16px 0; padding: 14px 12px; background: #fff; border: 1px solid #e8e8ec; border-radius: 6px; }'
        . '.yoshi-recent-games__heading { font-size: 13px; font-weight: 700; color: #333; margin: 0 0 10px; padding-bottom: 6px; border-bottom: 2px solid var(--orange, #f5811f); }'
        . '.yoshi-recent-games__bar { display: flex; gap: 4px; margin-bottom: 10px; }'
        . '.yoshi-recent-games__cell { flex: 1; padding: 6px 0; text-align: center; font-size: 14px; font-weight: 700; color: #fff; border-radius: 3px; }'
        . '.yoshi-recent-games__cell--w { background: var(--green, #2e8b57); }'
        . '.yoshi-recent-games__cell--l { background: var(--red, #e53935); }'
        . '.yoshi-recent-games__cell--n { background: #999; }'
        . '.yoshi-recent-games__list { list-style: none; margin: 0; padding: 0; font-size: 12px; line-height: 1.5; }'
        . '.yoshi-recent-games__item { margin: 0; padding: 4px 0; border-bottom: 1px dotted #eee; }'
        . '.yoshi-recent-games__item:last-child { border-bottom: 0; }'
        . '.yoshi-recent-games__date { color: #999; margin-right: 6px; }'
        . '.yoshi-recent-games__result { display: inline-block; width: 1.5em; text-align: center; font-weight: 700; margin-right: 6px; }'
        . '.yoshi-recent-games__result--w { color: var(--green, #2e8b57); }'
        . '.yoshi-recent-games__result--l { color: var(--red, #e53935); }'
        . '.yoshi-recent-games__result--n { color: #999; }'
        . '.yoshi-recent-games__title { color: #333; text-decoration: none; }'
        . '.yoshi-recent-games__title:hover { color: var(--orange, #f5811f); }'
        . '</style>';

    $html  = $style;
    $html .= '<aside class="yoshi-recent-games" aria-label="直近の試合結果">';
    $html .= '<p class="yoshi-recent-games__heading">📊 直近' . esc_html( (string) $count ) . '試合</p>';

    $html .= '<div class="yoshi-recent-games__bar">';
    foreach ( array_reverse( $games ) as $g ) {
        $cls   = $g['result'] === 'W' ? 'w' : ( $g['result'] === 'L' ? 'l' : 'n' );
        $label = $g['result'] === 'W' ? '○' : ( $g['result'] === 'L' ? '●' : '-' );
        $html .= '<span class="yoshi-recent-games__cell yoshi-recent-games__cell--' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</span>';
    }
    $html .= '</div>';

    $html .= '<ul class="yoshi-recent-games__list">';
    foreach ( $games as $g ) {
        $cls   = $g['result'] === 'W' ? 'w' : ( $g['result'] === 'L' ? 'l' : 'n' );
        $label = $g['result'] === 'W' ? '勝' : ( $g['result'] === 'L' ? '負' : '-' );
        $html .= '<li class="yoshi-recent-games__item">';
        $html .= '<span class="yoshi-recent-games__date">' . esc_html( $g['date'] ) . '</span>';
        $html .= '<span class="yoshi-recent-games__result yoshi-recent-games__result--' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</span>';
        $html .= '<a class="yoshi-recent-games__title" href="' . esc_url( $g['url'] ) . '">' . esc_html( wp_trim_words( $g['title'], 12, '…' ) ) . '</a>';
        $html .= '</li>';
    }
    $html .= '</ul>';
    $html .= '</aside>';

    return $html;
}
add_shortcode( 'yoshi_recent_games', 'yoshilover_063_render_recent_games_widget' );

/**
 * 直近 10 試合から連勝 / 連敗 streak を計算。
 *
 * @return array{type:string, count:int}
 *         type: 'win' / 'loss' / 'none'
 */
function yoshilover_063_calculate_streak() {
    $games = yoshilover_063_get_recent_games_results( 10 );
    if ( empty( $games ) ) {
        return array( 'type' => 'none', 'count' => 0 );
    }
    $first = $games[0]['result'];
    if ( $first === '-' ) {
        return array( 'type' => 'none', 'count' => 0 );
    }
    $count = 0;
    foreach ( $games as $g ) {
        if ( $g['result'] === $first ) {
            $count++;
        } else {
            break;
        }
    }
    return array(
        'type'  => $first === 'W' ? 'win' : 'loss',
        'count' => $count,
    );
}

/**
 * Streak badge HTML を生成。
 *
 * shortcode: [yoshi_streak_badge]
 *
 * 1 試合だけの結果(streak 不成立)では表示しない、2 連以上から表示。
 */
function yoshilover_063_render_streak_badge( $atts ) {
    $streak = yoshilover_063_calculate_streak();
    if ( $streak['count'] < 2 || $streak['type'] === 'none' ) {
        return '';
    }

    $is_win = $streak['type'] === 'win';
    $emoji  = $is_win ? '🔥' : '😢';
    $cls    = $is_win ? 'win' : 'loss';
    $label  = $is_win ? ( $streak['count'] . ' 連勝中' ) : ( $streak['count'] . ' 連敗中' );

    $style = '<style id="yoshi-streak-badge-inline-css">'
        . '.yoshi-streak-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; margin: 8px 0; border-radius: 999px; font-size: 13px; font-weight: 700; }'
        . '.yoshi-streak-badge--win { background: var(--green, #2e8b57); color: #fff; }'
        . '.yoshi-streak-badge--loss { background: #999; color: #fff; }'
        . '.yoshi-streak-badge__emoji { font-size: 14px; line-height: 1; }'
        . '</style>';

    $html  = $style;
    $html .= '<span class="yoshi-streak-badge yoshi-streak-badge--' . esc_attr( $cls ) . '" aria-label="' . esc_attr( $label ) . '">';
    $html .= '<span class="yoshi-streak-badge__emoji">' . esc_html( $emoji ) . '</span>';
    $html .= '<span>' . esc_html( $label ) . '</span>';
    $html .= '</span>';

    return $html;
}
add_shortcode( 'yoshi_streak_badge', 'yoshilover_063_render_streak_badge' );

/* ============================================================
 * W5: 1 年前の今日 widget (SIDEBAR-WIDGETS Phase 2)
 *
 * shortcode で sidebar の Custom HTML widget に貼って使用:
 *   [yoshi_this_day_in_history]
 *
 * WP_Query で 1 年前同日 ±2 日の publish を取得、最大 3 件 list。
 * 1 年分以上の post 履歴 がない時 (新サイト) は何も表示しない。
 * ============================================================ */

/**
 * 1 年前の同日 ±day_window 日に publish された post を最大 N 件取得。
 *
 * @param int $count 取得件数 (1-5)
 * @param int $day_window 同日前後の day range (default 2)
 * @return array<int, array{id:int, title:string, url:string, date:string}>
 */
function yoshilover_063_get_this_day_in_history( $count = 3, $day_window = 2 ) {
    $count = max( 1, min( 5, intval( $count ) ) );
    $day_window = max( 0, min( 7, intval( $day_window ) ) );

    $cache_key = sprintf( 'yoshi_thisday_%d_%d', $count, $day_window );
    $cached = get_transient( $cache_key );
    if ( is_array( $cached ) ) {
        return $cached;
    }

    $now = current_time( 'timestamp' );
    $year_ago = strtotime( '-1 year', $now );
    $start = strtotime( sprintf( '-%d days', $day_window ), $year_ago );
    $end   = strtotime( sprintf( '+%d days', $day_window ), $year_ago );

    $args = array(
        'posts_per_page' => $count,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'date_query'     => array(
            array(
                'after'     => date( 'Y-m-d', $start ),
                'before'    => date( 'Y-m-d', $end ),
                'inclusive' => true,
            ),
        ),
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    );
    $q = new WP_Query( $args );
    $results = array();
    foreach ( $q->posts as $p ) {
        $results[] = array(
            'id'    => (int) $p->ID,
            'title' => get_the_title( $p ),
            'url'   => get_permalink( $p ),
            'date'  => get_the_date( 'Y/n/j', $p ),
        );
    }
    wp_reset_postdata();

    // 6h cache (毎日 0 時に新しい "今日" が始まるが、6h cache で十分)
    set_transient( $cache_key, $results, 6 * 60 * 60 );
    return $results;
}

/**
 * 1 年前の今日 widget HTML 生成。
 *
 * shortcode: [yoshi_this_day_in_history count="3"]
 */
function yoshilover_063_render_this_day_in_history( $atts ) {
    $atts  = shortcode_atts(
        array( 'count' => 3, 'day_window' => 2 ),
        $atts,
        'yoshi_this_day_in_history'
    );
    $count = max( 1, min( 5, intval( $atts['count'] ) ) );
    $window = max( 0, min( 7, intval( $atts['day_window'] ) ) );
    $items = yoshilover_063_get_this_day_in_history( $count, $window );
    if ( empty( $items ) ) {
        return '';
    }

    $year_ago_jp = date_i18n( 'Y年n月j日', strtotime( '-1 year', current_time( 'timestamp' ) ) );

    $style = '<style id="yoshi-thisday-inline-css">'
        . '.yoshi-thisday { margin: 16px 0; padding: 14px 12px; background: #fff; border: 1px solid #e8e8ec; border-radius: 6px; }'
        . '.yoshi-thisday__heading { font-size: 13px; font-weight: 700; color: #333; margin: 0 0 4px; padding-bottom: 6px; border-bottom: 2px solid var(--blue, #003da5); }'
        . '.yoshi-thisday__sub { font-size: 11px; color: #999; margin: 0 0 8px; }'
        . '.yoshi-thisday__list { list-style: none; margin: 0; padding: 0; font-size: 12px; line-height: 1.5; }'
        . '.yoshi-thisday__item { margin: 0; padding: 5px 0; border-bottom: 1px dotted #eee; }'
        . '.yoshi-thisday__item:last-child { border-bottom: 0; }'
        . '.yoshi-thisday__date { color: #999; margin-right: 6px; font-size: 11px; }'
        . '.yoshi-thisday__title { color: #333; text-decoration: none; }'
        . '.yoshi-thisday__title:hover { color: var(--orange, #f5811f); }'
        . '</style>';

    $html  = $style;
    $html .= '<aside class="yoshi-thisday" aria-label="1年前の今日">';
    $html .= '<p class="yoshi-thisday__heading">📜 1年前の今日</p>';
    $html .= '<p class="yoshi-thisday__sub">' . esc_html( $year_ago_jp ) . ' 前後の記事</p>';
    $html .= '<ul class="yoshi-thisday__list">';
    foreach ( $items as $it ) {
        $html .= '<li class="yoshi-thisday__item">';
        $html .= '<span class="yoshi-thisday__date">' . esc_html( $it['date'] ) . '</span>';
        $html .= '<a class="yoshi-thisday__title" href="' . esc_url( $it['url'] ) . '">'
              . esc_html( wp_trim_words( $it['title'], 14, '…' ) )
              . '</a>';
        $html .= '</li>';
    }
    $html .= '</ul>';
    $html .= '</aside>';

    return $html;
}
add_shortcode( 'yoshi_this_day_in_history', 'yoshilover_063_render_this_day_in_history' );
